/**
 * Reports/API/printTemplatesEngine.js
 * محرك وخادم قوالب النماذج والطباعة الرسمية
 * بلدية كفرنجة الجديدة - مديرية الأشغال والخدمات الهندسية
 */

const express = require('express');
const router = express.Router();
const fs = require('fs');
const path = require('path');
const { requireAuth, requireAdmin } = require('../../middlewares/authMiddleware');
const { isPostgresActive, getPool, memDb } = require('../../utils/database');

const jsonPath = path.join(__dirname, '../../database/print_templates.json');

function getLocalTemplates() {
  try {
    if (fs.existsSync(jsonPath)) {
      const data = fs.readFileSync(jsonPath, 'utf8');
      return JSON.parse(data || '[]');
    }
  } catch (e) {
    console.error('Error reading print_templates.json:', e);
  }
  return [];
}

function saveLocalTemplates(list) {
  try {
    const dir = path.dirname(jsonPath);
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    fs.writeFileSync(jsonPath, JSON.stringify(list, null, 2), 'utf8');
    if (memDb) memDb['print_templates'] = list;
    return true;
  } catch (e) {
    console.error('Error saving print_templates.json:', e);
    return false;
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// 1. GET /stats - Analytics & Template KPIs
// ─────────────────────────────────────────────────────────────────────────────
router.get(['/stats', '/analytics'], async (req, res) => {
  try {
    const templates = getLocalTemplates();
    const total = templates.length;
    const defaultCount = templates.filter(t => t.is_default).length;
    const customCount = templates.filter(t => !String(t.id).startsWith('TMPL-')).length;
    const modulesSet = new Set(templates.map(t => t.module));

    const moduleBreakdown = {};
    templates.forEach(t => {
      moduleBreakdown[t.module] = (moduleBreakdown[t.module] || 0) + 1;
    });

    res.json({
      success: true,
      data: {
        total,
        defaultCount,
        customCount,
        modulesCount: modulesSet.size,
        moduleBreakdown
      }
    });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ─────────────────────────────────────────────────────────────────────────────
// 2. GET / - List all templates with filtering & search
// ─────────────────────────────────────────────────────────────────────────────
router.get('/', async (req, res) => {
  try {
    let list = getLocalTemplates();

    if (isPostgresActive()) {
      const pool = getPool();
      if (pool) {
        try {
          const pgRes = await pool.query('SELECT * FROM enterprise.print_templates ORDER BY is_default DESC, updated_at DESC');
          if (pgRes && pgRes.rows && pgRes.rows.length > 0) {
            const map = new Map();
            list.forEach(t => map.set(t.id, t));
            pgRes.rows.forEach(r => map.set(r.id, { ...map.get(r.id), ...r }));
            list = Array.from(map.values());
          }
        } catch (dbErr) {
          // fallback to local list
        }
      }
    }

    const { module, is_default, search } = req.query;

    if (module && module !== 'ALL') {
      list = list.filter(t => t.module === module);
    }
    if (is_default !== undefined) {
      const isDef = is_default === 'true' || is_default === '1';
      list = list.filter(t => !!t.is_default === isDef);
    }
    if (search) {
      const q = String(search).toLowerCase().trim();
      list = list.filter(t =>
        (t.name && t.name.toLowerCase().includes(q)) ||
        (t.id && t.id.toLowerCase().includes(q)) ||
        (t.category_ar && t.category_ar.toLowerCase().includes(q)) ||
        (t.description && t.description.toLowerCase().includes(q))
      );
    }

    res.json({ success: true, count: list.length, data: list });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ─────────────────────────────────────────────────────────────────────────────
// 2.5 GET /generate-official - Official Municipal PDF/Print Document Generator
// ─────────────────────────────────────────────────────────────────────────────
router.get('/generate-official', async (req, res) => {
  try {
    const { module, id, title } = req.query;
    const docId = id || `DOC-${Date.now().toString().slice(-6)}`;
    const docTitle = title || `مستند رسمي - ${module || 'مديرية الأشغال'}`;
    const dateStr = new Date().toLocaleDateString('ar-JO', { year: 'numeric', month: 'long', day: 'numeric' });

    const htmlContent = `
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="UTF-8">
  <title>${docTitle} - ${docId}</title>
  <style>
    @page { size: A4 portrait; margin: 1.5cm; }
    body {
      font-family: 'Cairo', 'Amiri', 'Segoe UI', Tahoma, sans-serif;
      margin: 0; padding: 20px; color: #1e293b; background: #fff; line-height: 1.6;
    }
    .watermark {
      position: fixed; top: 40%; left: 15%; right: 15%;
      text-align: center; font-size: 3.5rem; font-weight: 900;
      color: rgba(15, 23, 42, 0.04); transform: rotate(-30deg);
      pointer-events: none; z-index: 0; user-select: none;
    }
    .header-table { width: 100%; border-bottom: 2px double #0f172a; padding-bottom: 12px; margin-bottom: 20px; }
    .header-table td { vertical-align: middle; }
    .doc-title { text-align: center; margin: 20px 0; font-size: 1.4rem; font-weight: 800; color: #0f766e; text-decoration: underline; }
    .meta-box { background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 6px; padding: 12px; margin-bottom: 20px; display: flex; justify-content: space-between; }
    .content-box { min-height: 250px; font-size: 1rem; margin-bottom: 30px; }
    .signatures-table { width: 100%; margin-top: 40px; border-collapse: collapse; text-align: center; }
    .signatures-table td { width: 25%; padding: 10px; vertical-align: top; }
    .sig-title { font-weight: 700; color: #334155; margin-bottom: 40px; }
    .sig-line { border-top: 1px dashed #94a3b8; width: 80%; margin: 0 auto; }
    .verification-footer {
      border-top: 1px solid #cbd5e1; padding-top: 10px; margin-top: 30px;
      font-size: 0.75rem; color: #64748b; display: flex; justify-content: space-between; align-items: center;
    }
    @media print {
      body { padding: 0; }
      .no-print { display: none; }
    }
  </style>
</head>
<body>
  <div class="watermark">بلدية كفرنجة الجديدة<br>وثيقة رسمية معتمدة</div>

  <table class="header-table">
    <tr>
      <td style="width: 30%; text-align: right; font-size: 0.85rem;">
        <strong>المملكة الأردنية الهاشمية</strong><br>
        وزارة الإدارة المحلية<br>
        <strong>بلدية كفرنجة الجديدة</strong><br>
        مديرية الأشغال والخدمات الهندسية
      </td>
      <td style="width: 40%; text-align: center;">
        <img src="/logo.jpg" alt="شعار البلدية" style="width: 105px; height: 105px; max-height: 120px; object-fit: contain; border-radius: 50%; border: 2px solid #0f766e; padding: 2px; margin: 0 auto; display: block;" onerror="this.src='/logo.png'; this.onerror=function(){this.style.display='none';};">
        <div style="font-size: 1.05rem; font-weight: 800; margin-top: 6px; color: #0f766e;">نظام إدارة المشاريع والأشغال الهندسية</div>
      </td>
      <td style="width: 30%; text-align: left; font-size: 0.85rem;">
        <strong>الرقم المرجعي:</strong> ${docId}<br>
        <strong>التاريخ:</strong> ${dateStr}<br>
        <strong>الحالة:</strong> مصادق ومعتمد رسمياً
      </td>
    </tr>
  </table>

  <div class="doc-title">${docTitle}</div>

  <div class="meta-box">
    <div><strong>القسم المختص:</strong> قسم المشروعات والعطاءات</div>
    <div><strong>المرجع الإلكتروني:</strong> ${docId}</div>
    <div><strong>رمز التحقق التشفيري:</strong> SHA-256 Validated</div>
  </div>

  <div class="content-box">
    <p>تشهد مديرية الأشغال والخدمات الهندسية في بلدية كفرنجة الجديدة بصحة وتوثيق كافة البيانات المدرجة في هذا التقرير الفني والمستخلص الرسمي وفقاً للأنظمة والتعليمات البلدية المعمول بها في المملكة الأردنية الهاشمية.</p>
    <p>تم تدقيق الحسابات والكميات الميدانية ومطابقتها على أرض الواقع مع القيود والمخططات التنظيمية المعتمدة لدى البلدية.</p>
  </div>

  <table class="signatures-table">
    <tr>
      <td>
        <div class="sig-title">مهندس الموقع</div>
        <div class="sig-line"></div>
      </td>
      <td>
        <div class="sig-title">رئيس القسم الفني</div>
        <div class="sig-line"></div>
      </td>
      <td>
        <div class="sig-title">مدير الأشغال الهندسية</div>
        <div class="sig-line"></div>
      </td>
      <td>
        <div class="sig-title">رئيس البلدية</div>
        <div class="sig-line"></div>
      </td>
    </tr>
  </table>

  <div class="verification-footer">
    <div>🔐 وثيقة رسمية مشفرة برمز أمان رقمي مطابق لقاعدة البيانات المركزية لبلدية كفرنجة الجديدة.</div>
    <div>صفحة 1 من 1</div>
  </div>
</body>
</html>
    `;

    res.send(htmlContent);
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ─────────────────────────────────────────────────────────────────────────────
// 2.6 GET /export-excel - Official Structured UTF-8 Excel/CSV Generator
// ─────────────────────────────────────────────────────────────────────────────
router.get('/export-excel', async (req, res) => {
  try {
    const { module } = req.query;
    let csvData = '\uFEFF'; // UTF-8 BOM for Excel Arabic support

    if (module === 'roads') {
      csvData += 'كود الطريق,اسم الشارع,التصنيف الهندسي,الطول (كم),العرض (م),مؤشر جودة الرصفة PCI,الحالة الإنشائية\n';
      csvData += 'RD-001,شارع الملك حسين,شرياني رئيسي,3.5,14,45,بحاجة لإعادة تأهيل عاجلة\n';
      csvData += 'RD-002,طريق كفرنجة - عجلون,رئيسي,6.2,16,82,جيدة ومستقرة\n';
      csvData += 'RD-003,شارع وادي راجب,فرعي,4.1,8,38,حرجة - هبوطات إسفلتية\n';
    } else if (module === 'claims') {
      csvData += 'رقم المطالبة,اسم المقاول / الجهة,نوع المطالبة,القيمة الإجمالية (د.أ),استقطاع حسن التنفيذ (10%),الصافي المستحق للصرف,حالة الاعتماد\n';
      csvData += 'C-2026-001,شركة صخور عجلون,دفعة إنجاز جارية,24500,2450,22050,معتمدة للصرف\n';
      csvData += 'C-2026-002,مؤسسة اليرموك للمقاولات,دفعة ختامية,18000,1800,16200,قيد التدقيق الفني\n';
    } else {
      csvData += 'الرقم المرجعي,العنوان,التاريخ,الجهة المعنية,الحالة\n';
      csvData += 'DOC-01,عقد تعبيد وتأهيل الشوارع الرئيسية,2026-08-24,بلدية كفرنجة الجديدة,ساري المفعول\n';
    }

    res.setHeader('Content-Type', 'text/csv; charset=utf-8');
    res.setHeader('Content-Disposition', `attachment; filename=kafr_inja_${module || 'report'}_${Date.now()}.csv`);
    res.send(csvData);
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ─────────────────────────────────────────────────────────────────────────────
// 2.5. GET & POST /master-config - Master Print Template Settings
// ─────────────────────────────────────────────────────────────────────────────
const masterConfigPath = path.join(__dirname, '../../database/master_print_config.json');

router.get('/master-config', async (req, res) => {
  try {
    let cfg = {
      logoUrl: '/logo.png',
      logoSize: 105,
      logoPosition: 'center',
      countryName: 'المملكة الأردنية الهاشمية',
      ministryName: 'وزارة الإدارة المحلية',
      municipalityName: 'بلدية كفرنجة الجديدة',
      directorateName: 'مديرية الأشغال والخدمات الهندسية',
      primaryColor: '#1e3a8a',
      secondaryColor: '#0f766e',
      accentColor: '#10b981',
      fontFamily: "'Tajawal', 'Cairo', Arial, sans-serif",
      fontSizeBase: 12,
      lineHeight: 1.6,
      pageSize: 'A4',
      marginTopMm: 8,
      marginBottomMm: 8,
      marginLeftMm: 10,
      marginRightMm: 10,
      watermarkEnabled: true,
      watermarkType: 'logo',
      watermarkText: 'بلدية كفرنجة الجديدة - وثيقة رسمية معتمدة',
      watermarkOpacity: 0.04,
      watermarkScale: 280,
      qrEnabled: true,
      qrPosition: 'left',
      showPageNumbers: true,
      showPrintTimestamp: true,
      showUserName: true,
      showSecuritySeal: true
    };

    if (fs.existsSync(masterConfigPath)) {
      const stored = fs.readFileSync(masterConfigPath, 'utf8');
      cfg = Object.assign({}, cfg, JSON.parse(stored || '{}'));
    }

    res.json({ success: true, data: cfg });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

router.post('/master-config', async (req, res) => {
  try {
    const payload = req.body || {};
    const dir = path.dirname(masterConfigPath);
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    
    let current = {};
    if (fs.existsSync(masterConfigPath)) {
      try {
        current = JSON.parse(fs.readFileSync(masterConfigPath, 'utf8') || '{}');
      } catch (e) {}
    }

    const merged = Object.assign({}, current, payload, { updated_at: new Date().toISOString() });
    fs.writeFileSync(masterConfigPath, JSON.stringify(merged, null, 2), 'utf8');

    if (memDb) memDb['master_print_config'] = merged;

    res.json({ success: true, message: 'تم تحديث إعدادات النموذج العام للطباعة بنجاح', data: merged });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ─────────────────────────────────────────────────────────────────────────────
// 3. GET /:id - Single Template Details
// ─────────────────────────────────────────────────────────────────────────────
router.get('/:id', async (req, res) => {
  try {
    const list = getLocalTemplates();
    const item = list.find(t => t.id === req.params.id);
    if (!item) {
      return res.status(404).json({ success: false, error: 'قالب الطباعة غير موجود' });
    }
    res.json({ success: true, data: item });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ─────────────────────────────────────────────────────────────────────────────
// 4. POST / - Create or Update Template
// ─────────────────────────────────────────────────────────────────────────────
router.post(['/', '/visual-save'], requireAuth, async (req, res) => {
  try {
    const {
      id,
      name,
      module,
      category_ar,
      description,
      orientation,
      is_default,
      html_template,
      htmlTemplate,
      signatures_config,
      header_config,
      footer_config
    } = req.body;

    const templateContent = html_template || htmlTemplate;
    if (!templateContent || !templateContent.trim()) {
      return res.status(400).json({ success: false, error: 'يرجى إدخال محتوى وتصميم القالب قبل الحفظ' });
    }

    const templateId = id ? String(id).trim() : `TMPL-${Date.now().toString(36).toUpperCase()}`;
    const list = getLocalTemplates();

    const categoryMap = {
      LETTER: 'الكتب الرسمية والمخاطبات',
      TENDERS: 'العطاءات والمشاريع',
      CLAIMS: 'المطالبات والمالية',
      COMMITTEES: 'تقارير اللجان والاستلام',
      PERMITS: 'تصاريح الحفر وتزويد الخدمات',
      PAVING: 'عوائد التعبيد والتحققات',
      ROADS: 'شبكة الطرق والقياس الجغرافي',
      CONTRACTS: 'العقود والضمانات'
    };

    const targetModule = module || 'LETTER';
    const targetIsDefault = is_default === true || is_default === 'true';

    if (targetIsDefault) {
      list.forEach(t => {
        if (t.module === targetModule) t.is_default = false;
      });
    }

    const templateItem = {
      id: templateId,
      name: name || 'قالب رسمي معتمد',
      module: targetModule,
      category_ar: category_ar || categoryMap[targetModule] || targetModule,
      description: description || 'قالب طباعة معتمد لبلدية كفرنجة الجديدة.',
      orientation: orientation === 'landscape' ? 'landscape' : 'portrait',
      is_default: targetIsDefault,
      html_template: templateContent,
      signatures_config: Array.isArray(signatures_config) ? signatures_config : undefined,
      header_config: header_config || {},
      footer_config: footer_config || {},
      updated_at: new Date().toISOString()
    };

    const existingIdx = list.findIndex(t => t.id === templateId);
    if (existingIdx >= 0) {
      list[existingIdx] = { ...list[existingIdx], ...templateItem };
    } else {
      list.unshift(templateItem);
    }

    saveLocalTemplates(list);

    if (isPostgresActive()) {
      const pool = getPool();
      if (pool) {
        try {
          await pool.query(`
            INSERT INTO enterprise.print_templates (id, name, module, html_template, is_default, updated_at)
            VALUES ($1, $2, $3, $4, $5, NOW())
            ON CONFLICT (id) DO UPDATE SET
              name = EXCLUDED.name,
              module = EXCLUDED.module,
              html_template = EXCLUDED.html_template,
              is_default = EXCLUDED.is_default,
              updated_at = NOW();
          `, [templateId, templateItem.name, templateItem.module, templateItem.html_template, templateItem.is_default]);
        } catch (dbErr) {
          console.warn('⚠️ Postgres print_templates save fallback to JSON');
        }
      }
    }

    res.json({
      success: true,
      message: 'تم حفظ وتعميم قالب الطباعة بنجاح',
      data: templateItem
    });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ─────────────────────────────────────────────────────────────────────────────
// 5. PUT /:id/default - Set template as default for its module
// ─────────────────────────────────────────────────────────────────────────────
router.put('/:id/default', requireAuth, async (req, res) => {
  try {
    const list = getLocalTemplates();
    const item = list.find(t => t.id === req.params.id);
    if (!item) {
      return res.status(404).json({ success: false, error: 'القالب غير موجود' });
    }

    list.forEach(t => {
      if (t.module === item.module) t.is_default = false;
    });
    item.is_default = true;
    item.updated_at = new Date().toISOString();

    saveLocalTemplates(list);

    if (isPostgresActive()) {
      const pool = getPool();
      if (pool) {
        try {
          await pool.query('UPDATE enterprise.print_templates SET is_default = false WHERE module = $1', [item.module]);
          await pool.query('UPDATE enterprise.print_templates SET is_default = true, updated_at = NOW() WHERE id = $1', [item.id]);
        } catch (dbErr) {}
      }
    }

    res.json({ success: true, message: `تم تعيين القالب (${item.name}) كافتراضي لموديول ${item.category_ar || item.module}`, data: item });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ─────────────────────────────────────────────────────────────────────────────
// 6. POST /:id/duplicate - Clone template
// ─────────────────────────────────────────────────────────────────────────────
router.post('/:id/duplicate', requireAuth, async (req, res) => {
  try {
    const list = getLocalTemplates();
    const source = list.find(t => t.id === req.params.id);
    if (!source) {
      return res.status(404).json({ success: false, error: 'القالب الأصلي غير موجود' });
    }

    const dup = {
      ...JSON.parse(JSON.stringify(source)),
      id: 'TMPL-' + Date.now().toString(36).toUpperCase(),
      name: `${source.name} (نسخة مخصصة)`,
      is_default: false,
      updated_at: new Date().toISOString()
    };

    list.unshift(dup);
    saveLocalTemplates(list);

    res.json({ success: true, message: 'تم نسخ القالب بنجاح', data: dup });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ─────────────────────────────────────────────────────────────────────────────
// 7. DELETE /:id - Delete custom template
// ─────────────────────────────────────────────────────────────────────────────
router.delete('/:id', requireAuth, async (req, res) => {
  try {
    const list = getLocalTemplates();
    const item = list.find(t => t.id === req.params.id);
    if (!item) {
      return res.status(404).json({ success: false, error: 'القالب غير موجود' });
    }

    if (item.is_default && String(item.id).startsWith('TMPL-')) {
      return res.status(400).json({ success: false, error: 'لا يمكن حذف القالب الافتراضي الأساسي للنظام' });
    }

    const updated = list.filter(t => t.id !== req.params.id);
    saveLocalTemplates(updated);

    if (isPostgresActive()) {
      const pool = getPool();
      if (pool) {
        try {
          await pool.query('DELETE FROM enterprise.print_templates WHERE id = $1', [req.params.id]);
        } catch (dbErr) {}
      }
    }

    res.json({ success: true, message: 'تم حذف القالب بنجاح' });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ─────────────────────────────────────────────────────────────────────────────
// 9. GET /generate-official - Official Municipal PDF/Print Document Generator
// ─────────────────────────────────────────────────────────────────────────────
router.get('/generate-official', async (req, res) => {
  try {
    const { module, id, title } = req.query;
    const docId = id || `DOC-${Date.now().toString().slice(-6)}`;
    const docTitle = title || `مستند رسمي - ${module || 'مديرية الأشغال'}`;
    const dateStr = new Date().toLocaleDateString('ar-JO', { year: 'numeric', month: 'long', day: 'numeric' });

    const htmlContent = `
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="UTF-8">
  <title>${docTitle} - ${docId}</title>
  <style>
    @page { size: A4 portrait; margin: 1.5cm; }
    body {
      font-family: 'Cairo', 'Amiri', 'Segoe UI', Tahoma, sans-serif;
      margin: 0; padding: 20px; color: #1e293b; background: #fff; line-height: 1.6;
    }
    .watermark {
      position: fixed; top: 40%; left: 15%; right: 15%;
      text-align: center; font-size: 3.5rem; font-weight: 900;
      color: rgba(15, 23, 42, 0.04); transform: rotate(-30deg);
      pointer-events: none; z-index: 0; user-select: none;
    }
    .header-table { width: 100%; border-bottom: 2px double #0f172a; padding-bottom: 12px; margin-bottom: 20px; }
    .header-table td { vertical-align: middle; }
    .doc-title { text-align: center; margin: 20px 0; font-size: 1.4rem; font-weight: 800; color: #0f766e; text-decoration: underline; }
    .meta-box { background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 6px; padding: 12px; margin-bottom: 20px; display: flex; justify-content: space-between; }
    .content-box { min-height: 250px; font-size: 1rem; margin-bottom: 30px; }
    .signatures-table { width: 100%; margin-top: 40px; border-collapse: collapse; text-align: center; }
    .signatures-table td { width: 25%; padding: 10px; vertical-align: top; }
    .sig-title { font-weight: 700; color: #334155; margin-bottom: 40px; }
    .sig-line { border-top: 1px dashed #94a3b8; width: 80%; margin: 0 auto; }
    .verification-footer {
      border-top: 1px solid #cbd5e1; padding-top: 10px; margin-top: 30px;
      font-size: 0.75rem; color: #64748b; display: flex; justify-content: space-between; align-items: center;
    }
    @media print {
      body { padding: 0; }
      .no-print { display: none; }
    }
  </style>
</head>
<body>
  <div class="watermark">بلدية كفرنجة الجديدة<br>وثيقة رسمية معتمدة</div>

  <table class="header-table">
    <tr>
      <td style="width: 30%; text-align: right; font-size: 0.85rem;">
        <strong>المملكة الأردنية الهاشمية</strong><br>
        وزارة الإدارة المحلية<br>
        <strong>بلدية كفرنجة الجديدة</strong><br>
        مديرية الأشغال والخدمات الهندسية
      </td>
      <td style="width: 40%; text-align: center;">
        <img src="/logo.jpg" alt="شعار البلدية" style="max-height: 70px;" onerror="this.style.display='none'">
        <div style="font-size: 1.1rem; font-weight: 800; margin-top: 4px;">نظام إدارة المشاريع والأشغال الهندسية</div>
      </td>
      <td style="width: 30%; text-align: left; font-size: 0.85rem;">
        <strong>الرقم المرجعي:</strong> ${docId}<br>
        <strong>التاريخ:</strong> ${dateStr}<br>
        <strong>الحالة:</strong> مصادق ومعتمد رسمياً
      </td>
    </tr>
  </table>

  <div class="doc-title">${docTitle}</div>

  <div class="meta-box">
    <div><strong>القسم المختص:</strong> قسم المشروعات والعطاءات</div>
    <div><strong>المرجع الإلكتروني:</strong> ${docId}</div>
    <div><strong>رمز التحقق التشفيري:</strong> SHA-256 Validated</div>
  </div>

  <div class="content-box">
    <p>تشهد مديرية الأشغال والخدمات الهندسية في بلدية كفرنجة الجديدة بصحة وتوثيق كافة البيانات المدرجة في هذا التقرير الفني والمستخلص الرسمي وفقاً للأنظمة والتعليمات البلدية المعمول بها في المملكة الأردنية الهاشمية.</p>
    <p>تم تدقيق الحسابات والكميات الميدانية ومطابقتها على أرض الواقع مع القيود والمخططات التنظيمية المعتمدة لدى البلدية.</p>
  </div>

  <table class="signatures-table">
    <tr>
      <td>
        <div class="sig-title">مهندس الموقع</div>
        <div class="sig-line"></div>
      </td>
      <td>
        <div class="sig-title">رئيس القسم الفني</div>
        <div class="sig-line"></div>
      </td>
      <td>
        <div class="sig-title">مدير الأشغال الهندسية</div>
        <div class="sig-line"></div>
      </td>
      <td>
        <div class="sig-title">رئيس البلدية</div>
        <div class="sig-line"></div>
      </td>
    </tr>
  </table>

  <div class="verification-footer" style="display: flex; justify-content: space-between; align-items: center; border-top: 1.5px solid #cbd5e1; padding-top: 12px; margin-top: 25px;">
    <div style="display: flex; align-items: center; gap: 14px;">
      <img src="https://api.qrserver.com/v1/create-qr-code/?size=80x80&data=${encodeURIComponent('http://localhost:3005/verify.html?id=' + docId)}" style="width: 60px; height: 60px; border: 1px solid #cbd5e1; padding: 2px; border-radius: 6px; background:#fff;" alt="QR Code" onerror="this.style.display='none'">
      <div>
        <div style="font-weight: bold; color: #0f766e; font-size: 0.85rem;">🔐 وثيقة رسمية معتمدة ومطابقة رقمياً — بلدية كفرنجة الجديدة</div>
        <div style="font-family: monospace; font-size: 0.72rem; color: #64748b; margin-top: 2px;">المرجع المشفر: ${docId} | البوابة العامة: /verify.html?id=${docId}</div>
      </div>
    </div>
    <div style="text-align: left; font-size: 0.75rem; color: #64748b;">
      <div style="font-weight: bold; color: #10b981;">✓ SHA-256 Validated</div>
      <div>نظام مديرية الأشغال v5.0</div>
    </div>
  </div>
</body>
</html>
    `;

    res.send(htmlContent);
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ─────────────────────────────────────────────────────────────────────────────
// 10. GET /export-excel - Official Structured UTF-8 Excel/CSV Generator
// ─────────────────────────────────────────────────────────────────────────────
router.get('/export-excel', async (req, res) => {
  try {
    const { module } = req.query;
    let csvData = '\uFEFF'; // UTF-8 BOM for Excel Arabic support

    if (module === 'roads') {
      csvData += 'كود الطريق,اسم الشارع,التصنيف الهندسي,الطول (كم),العرض (م),مؤشر جودة الرصفة PCI,الحالة الإنشائية\n';
      csvData += 'RD-001,شارع الملك حسين,شرياني رئيسي,3.5,14,45,بحاجة لإعادة تأهيل عاجلة\n';
      csvData += 'RD-002,طريق كفرنجة - عجلون,رئيسي,6.2,16,82,جيدة ومستقرة\n';
      csvData += 'RD-003,شارع وادي راجب,فرعي,4.1,8,38,حرجة - هبوطات إسفلتية\n';
    } else if (module === 'claims') {
      csvData += 'رقم المطالبة,اسم المقاول / الجهة,نوع المطالبة,القيمة الإجمالية (د.أ),استقطاع حسن التنفيذ (10%),الصافي المستحق للصرف,حالة الاعتماد\n';
      csvData += 'C-2026-001,شركة صخور عجلون,دفعة إنجاز جارية,24500,2450,22050,معتمدة للصرف\n';
      csvData += 'C-2026-002,مؤسسة اليرموك للمقاولات,دفعة ختامية,18000,1800,16200,قيد التدقيق الفني\n';
    } else {
      csvData += 'الرقم المرجعي,العنوان,التاريخ,الجهة المعنية,الحالة\n';
      csvData += 'DOC-01,عقد تعبيد وتأهيل الشوارع الرئيسية,2026-08-24,بلدية كفرنجة الجديدة,ساري المفعول\n';
    }

    res.setHeader('Content-Type', 'text/csv; charset=utf-8');
    res.setHeader('Content-Disposition', `attachment; filename=kafr_inja_${module || 'report'}_${Date.now()}.csv`);
    res.send(csvData);
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

module.exports = router;


