/**
 * Administration/API/tasksEngine.js
 * محرك إدارة المهام والتكليفات الفنية والكشوفات الميدانية
 * بلدية كفرنجة الجديدة - الإصدار الموحد v4.0
 */

const express = require('express');
const router = express.Router();
const path = require('path');
const fs = require('fs');
const multer = require('multer');
const { requireAuth } = require('../../middlewares/authMiddleware');
const { authorize } = require('../../middlewares/rbacManager');
const {
  dbQuery,
  dbGet,
  dbRun,
  generateSequenceId,
  isPostgresActive,
  memDb,
  saveMemTable
} = require('../../utils/database');

const UPLOADS_DIR = path.resolve(__dirname, '..', '..', 'uploads');
if (!fs.existsSync(UPLOADS_DIR)) fs.mkdirSync(UPLOADS_DIR, { recursive: true });

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, UPLOADS_DIR),
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase();
    const safeName = Date.now() + '-' + Math.round(Math.random() * 1e9) + ext;
    cb(null, safeName);
  }
});

const upload = multer({ storage, limits: { fileSize: 50 * 1024 * 1024 } });

function memGet(table, id) {
  if (!memDb[table]) return null;
  return memDb[table].find(r => String(r.id) === String(id)) || null;
}

function memInsert(table, item) {
  if (!memDb[table]) memDb[table] = [];
  memDb[table].unshift(item);
  saveMemTable(table);
  return item;
}

function memUpdate(table, id, updates) {
  if (!memDb[table]) return null;
  const idx = memDb[table].findIndex(r => String(r.id) === String(id));
  if (idx !== -1) {
    memDb[table][idx] = { ...memDb[table][idx], ...updates, updatedAt: new Date().toISOString() };
    saveMemTable(table);
    return memDb[table][idx];
  }
  return null;
}

function memDelete(table, id) {
  if (!memDb[table]) return false;
  memDb[table] = memDb[table].filter(r => String(r.id) !== String(id));
  saveMemTable(table);
  return true;
}

let isTasksMigrated = false;
async function ensureTasksSchema() {
  if (isTasksMigrated || !isPostgresActive()) return;
  try {
    await dbRun(`
      ALTER TABLE tasks ADD COLUMN IF NOT EXISTS "relatedTenderId" VARCHAR(100);
      ALTER TABLE tasks ADD COLUMN IF NOT EXISTS notes TEXT;
      ALTER TABLE tasks ADD COLUMN IF NOT EXISTS "createdBy" VARCHAR(50);
      ALTER TABLE tasks ADD COLUMN IF NOT EXISTS "completionNotes" TEXT;
      ALTER TABLE tasks ADD COLUMN IF NOT EXISTS "completionPercentage" DOUBLE PRECISION DEFAULT 0;
      ALTER TABLE tasks ADD COLUMN IF NOT EXISTS "attachmentPath" TEXT;
    `);
    isTasksMigrated = true;
  } catch (e) {
    console.warn('Tasks schema ensure note:', e.message);
  }
}

// 1. استرجاع قائمة المهام
router.get('/', requireAuth, async (req, res) => {
  await ensureTasksSchema();
  const { search, status, priority, assignedTo, page, limit } = req.query;
  try {
    if (isPostgresActive()) {
      let sql = 'SELECT * FROM tasks WHERE 1=1';
      const params = [];
      if (search) {
        params.push(`%${search}%`);
        sql += ` AND (title ILIKE $${params.length} OR id ILIKE $${params.length} OR description ILIKE $${params.length})`;
      }
      if (status) {
        params.push(status);
        sql += ` AND status = $${params.length}`;
      }
      if (priority) {
        params.push(priority);
        sql += ` AND priority = $${params.length}`;
      }
      if (assignedTo) {
        params.push(assignedTo);
        sql += ` AND "assignedTo" = $${params.length}`;
      }
      sql += ' ORDER BY "createdAt" DESC';

      if (page && limit) {
        const offset = (parseInt(page, 10) - 1) * parseInt(limit, 10);
        sql += ` LIMIT ${parseInt(limit, 10)} OFFSET ${offset}`;
      }

      const rows = await dbQuery(sql, params);
      return res.json(rows || []);
    }

    let rows = (memDb.tasks || []).filter(r => {
      if (search && !(`${r.title || ''} ${r.description || ''} ${r.id}`).toLowerCase().includes(search.toLowerCase())) return false;
      if (status && r.status !== status) return false;
      if (priority && r.priority !== priority) return false;
      if (assignedTo && r.assignedTo !== assignedTo) return false;
      return true;
    }).sort((a, b) => new Date(b.createdAt || 0) - new Date(a.createdAt || 0));

    if (page && limit) {
      const p = parseInt(page, 10);
      const l = parseInt(limit, 10);
      rows = rows.slice((p - 1) * l, p * l);
    }

    res.json(rows || []);
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// 2. استرجاع مهمة محددة
router.get('/:id', requireAuth, async (req, res) => {
  await ensureTasksSchema();
  try {
    let row;
    if (isPostgresActive()) {
      row = await dbGet('SELECT * FROM tasks WHERE id = $1', [req.params.id]);
    } else {
      row = memGet('tasks', req.params.id);
    }
    if (!row) return res.status(404).json({ error: 'المهمة غير موجودة' });
    res.json(row);
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// 3. إنشاء مهمة جديدة
router.post('/', requireAuth, authorize('tasks:create'), async (req, res) => {
  await ensureTasksSchema();
  const { title, description, assignedTo, priority, dueDate, relatedTenderId, status, notes } = req.body;
  if (!title) return res.status(400).json({ error: 'عنوان المهمة مطلوب' });

  try {
    const id = await generateSequenceId('TK', 'tasks');
    const now = new Date().toISOString();
    const createdBy = req.user ? req.user.id : 'نظام';
    const due = dueDate || null;

    if (isPostgresActive()) {
      try {
        await dbRun(`
          INSERT INTO tasks (
            id, title, description, "assignedTo", priority, "dueDate",
            "relatedTenderId", status, notes, "createdBy", "createdAt", "updatedAt"
          ) VALUES (
            $1, $2, $3, $4, $5, $6, $7, $8, $9, $10, NOW(), NOW()
          )
        `, [
          id, title, description || '', assignedTo || '', priority || 'متوسطة',
          due, relatedTenderId || '', status || 'جديدة', notes || '', createdBy
        ]);
      } catch (dbE) {
        await dbRun(`
          INSERT INTO tasks (
            id, title, description, "assignedTo", priority, status, "createdAt", "updatedAt"
          ) VALUES (
            $1, $2, $3, $4, $5, $6, NOW(), NOW()
          )
        `, [id, title, description || '', assignedTo || '', priority || 'متوسطة', status || 'جديدة']);
      }
    } else {
      memInsert('tasks', {
        id, title, description: description || '', assignedTo: assignedTo || '', priority: priority || 'متوسطة',
        dueDate: dueDate || '', relatedTenderId: relatedTenderId || '', status: status || 'جديدة',
        notes: notes || '', createdBy, createdAt: now, updatedAt: now
      });
    }

    res.status(201).json({ id, message: 'تم إسناد المهمة بنجاح', success: true });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// 4. تعديل مهمة
router.put('/:id', requireAuth, authorize('tasks:edit'), async (req, res) => {
  const { title, description, assignedTo, priority, dueDate, relatedTenderId, status, notes, completionNotes } = req.body;
  try {
    if (isPostgresActive()) {
      await dbRun(`
        UPDATE tasks SET
          title=$1, description=$2, "assignedTo"=$3, priority=$4, "dueDate"=$5,
          "relatedTenderId"=$6, status=$7, notes=$8, "completionNotes"=$9, "updatedAt"=NOW()
        WHERE id=$10
      `, [
        title, description || '', assignedTo || '', priority || 'متوسطة', dueDate || '',
        relatedTenderId || '', status || 'جديدة', notes || '', completionNotes || '', req.params.id
      ]);
    } else {
      memUpdate('tasks', req.params.id, {
        title, description: description || '', assignedTo: assignedTo || '', priority: priority || 'متوسطة',
        dueDate: dueDate || '', relatedTenderId: relatedTenderId || '', status: status || 'جديدة',
        notes: notes || '', completionNotes: completionNotes || ''
      });
    }

    res.json({ success: true, message: 'تم تحديث المهمة بنجاح' });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// 5. تقرير إنجاز مهمة مع رفع صور فنية
router.post('/:id/report', requireAuth, upload.single('file'), async (req, res) => {
  const { reportText, completionPercentage, status } = req.body;
  try {
    const attachment = req.file ? req.file.filename : '';
    if (isPostgresActive()) {
      await dbRun(`
        UPDATE tasks SET
          "completionNotes" = $1, "completionPercentage" = $2, status = $3,
          "attachmentPath" = COALESCE(NULLIF($4, ''), "attachmentPath"), "updatedAt" = NOW()
        WHERE id = $5
      `, [
        reportText || '', parseFloat(completionPercentage) || 100, status || 'مكتملة', attachment, req.params.id
      ]);
    } else {
      const updates = {
        completionNotes: reportText || '',
        completionPercentage: parseFloat(completionPercentage) || 100,
        status: status || 'مكتملة'
      };
      if (attachment) updates.attachmentPath = attachment;
      memUpdate('tasks', req.params.id, updates);
    }

    res.json({ success: true, message: 'تم حفظ تقرير إنجاز المهمة بنجاح' });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// 5.1 نموذج الكشف والمعاينة الميدانية الهندسية بالـ GPS وقوائم التدقيق (Field Inspection & GPS Stamping)
router.post('/:id/inspection', requireAuth, upload.array('photos', 5), async (req, res) => {
  const {
    inspectorName, inspectionDate, lat, lng, checklist,
    notes, recommendation, asphaltQuality, safetyCompliant
  } = req.body;

  const user = req.user || { fullName: 'مهندس الموقع', role: 'engineer' };
  const uploadedPhotos = (req.files || []).map(f => f.filename);
  const checklistObj = typeof checklist === 'string' ? JSON.parse(checklist || '{}') : (checklist || {});

  const inspectionReport = {
    id: `INSP-${Date.now()}`,
    task_id: req.params.id,
    inspector: inspectorName || user.fullName || user.username || 'م. الموقع',
    inspection_date: inspectionDate || new Date().toISOString().split('T')[0],
    gps_lat: parseFloat(lat || 32.3301),
    gps_lng: parseFloat(lng || 35.7501),
    checklist: checklistObj,
    asphalt_quality: asphaltQuality || 'جيدة ومطابقة للمواصفة',
    safety_compliant: safetyCompliant !== 'false' && safetyCompliant !== false,
    recommendation: recommendation || 'الموافقة على الاستلام وتثبيت الواقع',
    notes: notes || '',
    photos: uploadedPhotos,
    created_at: new Date().toISOString()
  };

  try {
    if (isPostgresActive()) {
      try {
        await dbRun(`
          UPDATE tasks SET
            "completionNotes" = $1,
            status = 'تم الكشف الميداني',
            "updatedAt" = NOW()
          WHERE id = $2
        `, [
          `كشف ميداني بواسطة (${inspectionReport.inspector}) - التوصية: ${inspectionReport.recommendation}`,
          req.params.id
        ]);
      } catch (e) {}
    } else {
      memUpdate('tasks', req.params.id, {
        completionNotes: `كشف ميداني بواسطة (${inspectionReport.inspector}) - التوصية: ${inspectionReport.recommendation}`,
        status: 'تم الكشف الميداني'
      });
    }

    // إشعار فوري
    const sendNotification = req.app ? req.app.get('sendNotification') : null;
    if (typeof sendNotification === 'function') {
      sendNotification({
        userId: 'all',
        title: '📋 كشف هندسي ميداني جديد',
        message: `تم توثيق كشف ميداني للمهمة (${req.params.id}) وتحديد الموقع الجغرافي والصور الفنية بنجاح`,
        link: `tasks:${req.params.id}`,
        type: 'tasks'
      });
    }

    res.status(201).json({
      success: true,
      message: '✅ تم توثيق الكشف الميداني الهندسي وربط الإحداثيات الجغرافية والصور بنجاح',
      inspection: inspectionReport
    });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// 5.2 استرجاع سجل الكشوفات والمعاينات الميدانية الحديثة
router.get('/inspections/recent', requireAuth, async (req, res) => {
  try {
    let rows = [];
    if (isPostgresActive()) {
      try {
        rows = await dbQuery('SELECT id, title, "assignedTo", status, "completionNotes", "updatedAt" FROM tasks WHERE status ILIKE \'%كشف%\' OR "completionNotes" IS NOT NULL ORDER BY "updatedAt" DESC LIMIT 50');
      } catch (e) {}
    }
    if (!rows.length) {
      rows = (memDb.tasks || []).filter(t => (t.status || '').includes('كشف') || t.completionNotes);
    }
    res.json({ success: true, count: rows.length, data: rows });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// 6. حذف مهمة
router.delete('/:id', requireAuth, authorize('tasks:delete'), async (req, res) => {
  try {
    if (isPostgresActive()) {
      await dbRun('DELETE FROM tasks WHERE id = $1', [req.params.id]);
    } else {
      memDelete('tasks', req.params.id);
    }
    res.json({ success: true, message: 'تم حذف المهمة بنجاح' });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

module.exports = router;
