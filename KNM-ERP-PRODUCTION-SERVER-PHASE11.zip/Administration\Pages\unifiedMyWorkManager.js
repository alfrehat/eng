/**
 * Administration/Pages/unifiedMyWorkManager.js
 * منظومة لوحة أعمالي الموكلة والمتابعة وإدارة الكشوفات والمهام الميدانية (v6.0 Enterprise)
 * بلدية كفرنجة الجديدة - مديرية الأشغال والخدمات الهندسية
 * ─────────────────────────────────────────────────────────────────────────────
 * التحديثات المعمارية الموحدة:
 * 1. تفعيل نظام رفع وعرض المرفقات والوثائق والصور (Attachment Uploader & In-App Document Viewer).
 * 2. ضبط أبعاد ومقاسات الصفحة والنوافذ المنبثقة لتناسب كافة الشاشات وأجهزة التابلت والموبايل.
 * 3. توحيد محرك الخرائط الجغرافية (GIS Engine) مع طبقات الأقمار الصناعية (Esri) والطبقات الطبوغرافية.
 * 4. توحيد محرك الطباعة والتقارير المعتمد (Print Engine) مع الترويسة والشعار الرسمي والتواقيع.
 * 5. لوحة مؤشرات أداء تفاعلية حية (Live Actionable KPI Dashboard).
 * 6. تبويبات فرعية: (أعمالي الموكلة، أعمال قمت بإسنادها، سجل الكشوفات الشامل، متابعة أعمال القسم).
 * 7. أوضاع عرض متعددة: جدول بيانات تفاعلي (Table)، لوحة كانبان (Kanban)، وخريطة جغرافية (GIS Map).
 */

(function () {
  'use strict';

  class UnifiedMyWorkManager {
    constructor() {
      this.container = null;
      this.activeTab = 'mine'; // 'mine', 'sent', 'registry', 'department'
      this.myWorkFilter = 'all'; // 'all', 'claims', 'tasks'
      this.viewMode = 'table'; // 'table', 'kanban', 'map'
      
      this.tasks = [];
      this.claims = [];
      this.users = [];
      this.workflowConfig = [];
      this.tenders = [];
      
      this.searchTerm = '';
      this.statusFilter = '';
      this.priorityFilter = '';
      this.assigneeFilter = '';
      
      this.currentUser = null;
      this.isLoading = false;
      this.mapInstance = null;
      this.modalMapInstance = null;
      this.modalMarker = null;
      
      this.selectedTaskFile = null;
      this.selectedReportFile = null;
      this.selectedCommentFile = null;

      this.initUser();
    }

    initUser() {
      try {
        const raw = localStorage.getItem('user') || localStorage.getItem('currentUser');
        this.currentUser = raw ? JSON.parse(raw) : (window.currentUser || { id: 'U-001', role: 'admin', fullName: 'مدير النظام' });
      } catch (e) {
        this.currentUser = { id: 'U-001', role: 'admin', fullName: 'مدير النظام' };
      }
    }

    isManagerOrAdmin() {
      if (!this.currentUser) return false;
      const role = (this.currentUser.role || '').toLowerCase();
      return ['admin', 'superadmin', 'manager', 'dept_head'].includes(role);
    }

    async init(containerId = 'my-work-tab-container') {
      this.container = document.getElementById(containerId);
      if (!this.container) {
        this.container = document.getElementById('page-my-work');
      }
      if (!this.container) return;

      this.initUser();
      this.renderSkeleton();
      await this.loadAllData();
    }

    renderSkeleton() {
      this.container.innerHTML = `
        <div class="unified-mywork-module" dir="rtl" style="width:100%; max-width:100%; box-sizing:border-box; padding:4px 0 30px 0;">
          
          <!-- Header Banner -->
          <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:14px; margin-bottom:18px; padding-bottom:14px; border-bottom:1px solid var(--border);">
            <div>
              <div style="display:flex; align-items:center; gap:8px;">
                <span style="font-size:1.6rem;">💼</span>
                <h2 style="margin:0; font-size:1.35rem; font-weight:800; color:var(--text);">لوحة أعمالي الموكلة والمتابعة والمهام الميدانية</h2>
              </div>
              <p style="margin:4px 0 0; font-size:0.83rem; color:var(--text-muted);">
                إدارة وتدقيق ومتابعة المعاملات والمهام المسندة، الكشوفات الهندسية، والمطالبات المالية قيد التدقيق والإجراء
              </p>
            </div>

            <div style="display:flex; gap:8px; flex-wrap:wrap; align-items:center;">
              <button class="btn btn-outline" onclick="unifiedMyWorkManager.loadAllData()" title="تحديث البيانات" style="display:flex; align-items:center; gap:5px; font-weight:700;">
                <span>🔄</span> <span>تحديث</span>
              </button>
              <button class="btn btn-outline" onclick="unifiedMyWorkManager.exportExcel()" title="تصدير إلى Excel" style="display:flex; align-items:center; gap:5px; font-weight:700;">
                <span>📤</span> <span>تصدير Excel</span>
              </button>
              <button class="btn btn-primary" id="btn-add-task-main" onclick="unifiedMyWorkManager.openTaskModal()" style="display:${this.isManagerOrAdmin() ? 'inline-flex' : 'none'}; align-items:center; gap:6px; font-weight:800; background:linear-gradient(135deg, #0284c7 0%, #0369a1 100%); border:none; box-shadow:0 4px 14px rgba(2,132,199,0.35);">
                <span>✨</span> <span>+ إسناد مهمة / كشف جديد</span>
              </button>
            </div>
          </div>

          <!-- KPI Summary Cards (Ultra-Clean 6-Column Responsive Grid) -->
          <div class="kpi-cards" id="mywork-kpi-container" style="display:grid; grid-template-columns:repeat(auto-fit, minmax(170px, 1fr)); gap:12px; margin-bottom:20px;">
            
            <div class="kpi-card" style="background:var(--bg-card); border:1px solid var(--border); border-right:4px solid var(--primary); border-radius:12px; padding:14px; box-shadow:0 2px 8px rgba(0,0,0,0.03); display:flex; justify-content:space-between; align-items:center;">
              <div>
                <div style="font-size:0.76rem; color:var(--text-muted); font-weight:700;">أعمال موكلة بانتظاري</div>
                <div class="kpi-value" id="kpi-my-actionable" style="font-size:1.45rem; font-weight:800; color:var(--primary); margin:4px 0 2px 0;">0</div>
                <div style="font-size:0.72rem; color:var(--primary);">تتطلب إجرائي</div>
              </div>
              <div style="font-size:2rem; opacity:0.85;">📥</div>
            </div>

            <div class="kpi-card" style="background:var(--bg-card); border:1px solid var(--border); border-right:4px solid #f59e0b; border-radius:12px; padding:14px; box-shadow:0 2px 8px rgba(0,0,0,0.03); display:flex; justify-content:space-between; align-items:center;">
              <div>
                <div style="font-size:0.76rem; color:var(--text-muted); font-weight:700;">مطالبات بانتظار إجرائي</div>
                <div class="kpi-value" id="kpi-my-claims" style="font-size:1.45rem; font-weight:800; color:#f59e0b; margin:4px 0 2px 0;">0</div>
                <div style="font-size:0.72rem; color:#f59e0b;">دفعات مالية</div>
              </div>
              <div style="font-size:2rem; opacity:0.85;">📝</div>
            </div>

            <div class="kpi-card" style="background:var(--bg-card); border:1px solid var(--border); border-right:4px solid #3b82f6; border-radius:12px; padding:14px; box-shadow:0 2px 8px rgba(0,0,0,0.03); display:flex; justify-content:space-between; align-items:center;">
              <div>
                <div style="font-size:0.76rem; color:var(--text-muted); font-weight:700;">مهام وكشوفات موكلة إليّ</div>
                <div class="kpi-value" id="kpi-my-tasks" style="font-size:1.45rem; font-weight:800; color:#3b82f6; margin:4px 0 2px 0;">0</div>
                <div style="font-size:0.72rem; color:#3b82f6;">معاينات فنية</div>
              </div>
              <div style="font-size:2rem; opacity:0.85;">📋</div>
            </div>

            <div class="kpi-card" style="background:var(--bg-card); border:1px solid var(--border); border-right:4px solid #8b5cf6; border-radius:12px; padding:14px; box-shadow:0 2px 8px rgba(0,0,0,0.03); display:flex; justify-content:space-between; align-items:center;">
              <div>
                <div style="font-size:0.76rem; color:var(--text-muted); font-weight:700;">أعمال قمت بإسنادها</div>
                <div class="kpi-value" id="kpi-my-sent" style="font-size:1.45rem; font-weight:800; color:#8b5cf6; margin:4px 0 2px 0;">0</div>
                <div style="font-size:0.72rem; color:#8b5cf6;">صادرة للمتابعة</div>
              </div>
              <div style="font-size:2rem; opacity:0.85;">📤</div>
            </div>

            <div class="kpi-card" style="background:var(--bg-card); border:1px solid var(--border); border-right:4px solid var(--success); border-radius:12px; padding:14px; box-shadow:0 2px 8px rgba(0,0,0,0.03); display:flex; justify-content:space-between; align-items:center;">
              <div>
                <div style="font-size:0.76rem; color:var(--text-muted); font-weight:700;">معاملات مكتملة</div>
                <div class="kpi-value" id="kpi-completed-tasks" style="font-size:1.45rem; font-weight:800; color:var(--success); margin:4px 0 2px 0;">0</div>
                <div style="font-size:0.72rem; color:var(--success);">تم إنجاز التقرير</div>
              </div>
              <div style="font-size:2rem; opacity:0.85;">✅</div>
            </div>

            <div class="kpi-card" style="background:var(--bg-card); border:1px solid var(--border); border-right:4px solid var(--danger); border-radius:12px; padding:14px; box-shadow:0 2px 8px rgba(0,0,0,0.03); display:flex; justify-content:space-between; align-items:center;">
              <div>
                <div style="font-size:0.76rem; color:var(--text-muted); font-weight:700;">تنبيهات ومتأخرات</div>
                <div class="kpi-value" id="kpi-overdue-tasks" style="font-size:1.45rem; font-weight:800; color:var(--danger); margin:4px 0 2px 0;">0</div>
                <div style="font-size:0.72rem; color:var(--danger);">تجاوزت الموعد</div>
              </div>
              <div style="font-size:2rem; opacity:0.85;">⚠️</div>
            </div>

          </div>

          <!-- Modern Navigation Tabs Header -->
          <div class="tabs-header" style="display:flex; gap:8px; border-bottom:2px solid var(--border); margin-bottom:20px; overflow-x:auto; padding-bottom:4px;">
            <button class="btn mw-tab-nav active" id="tab-btn-mine" onclick="unifiedMyWorkManager.switchTab('mine')" style="border-radius:8px 8px 0 0; border-bottom:3px solid var(--primary); font-weight:700; display:flex; align-items:center; gap:6px; padding:10px 16px; border:none; background:transparent; color:var(--primary); cursor:pointer;">
              <span>📥</span> <span>أعمالي الموكلة بانتظاري</span>
              <span class="badge" id="badge-tab-mine" style="background:var(--primary); color:#fff; border-radius:10px; font-size:0.75rem; padding:2px 6px;">0</span>
            </button>
            <button class="btn mw-tab-nav" id="tab-btn-sent" onclick="unifiedMyWorkManager.switchTab('sent')" style="border-radius:8px 8px 0 0; border-bottom:3px solid transparent; font-weight:700; display:flex; align-items:center; gap:6px; padding:10px 16px; border:none; background:transparent; color:var(--text-muted); cursor:pointer;">
              <span>📤</span> <span>أعمال قمت بإسنادها ومتابعتها</span>
              <span class="badge" id="badge-tab-sent" style="background:#8b5cf6; color:#fff; border-radius:10px; font-size:0.75rem; padding:2px 6px;">0</span>
            </button>
            <button class="btn mw-tab-nav" id="tab-btn-registry" onclick="unifiedMyWorkManager.switchTab('registry')" style="border-radius:8px 8px 0 0; border-bottom:3px solid transparent; font-weight:700; display:flex; align-items:center; gap:6px; padding:10px 16px; border:none; background:transparent; color:var(--text-muted); cursor:pointer;">
              <span>📋</span> <span>سجل الكشوفات والمهام الشامل</span>
              <span class="badge" id="badge-tab-registry" style="background:var(--text-muted); color:#fff; border-radius:10px; font-size:0.75rem; padding:2px 6px;">0</span>
            </button>
            <button class="btn mw-tab-nav" id="tab-btn-department" onclick="unifiedMyWorkManager.switchTab('department')" style="border-radius:8px 8px 0 0; border-bottom:3px solid transparent; font-weight:700; display:${this.isManagerOrAdmin() ? 'flex' : 'none'}; align-items:center; gap:6px; padding:10px 16px; border:none; background:transparent; color:var(--text-muted); cursor:pointer;">
              <span>👥</span> <span>متابعة أعمال القسم والكوادر</span>
            </button>
          </div>

          <!-- Tab Content Sections -->
          <div id="umw-tab-content-area">
            <div style="text-align:center; padding:50px 20px; color:var(--text-muted);">
              <div class="spinner" style="margin:0 auto 15px auto;"></div>
              <p>جارٍ تحميل بيانات الأعمال الموكلة والكشوفات الهندسية...</p>
            </div>
          </div>
        </div>

        <!-- Global In-App Document / Media Viewer Modal -->
        <div id="umw-viewer-modal" class="umw-modal-overlay" style="display:none; position:fixed; inset:0; background:rgba(15,23,42,0.85); backdrop-filter:blur(6px); z-index:99999; align-items:center; justify-content:center; padding:16px;">
          <div class="umw-modal-dialog" style="background:var(--bg-card); border:1px solid var(--border); border-radius:16px; width:min(1000px, 96vw); height:min(90vh, 850px); display:flex; flex-direction:column; overflow:hidden; box-shadow:0 25px 50px -12px rgba(0,0,0,0.5);">
            <div style="padding:14px 20px; border-bottom:1px solid var(--border); display:flex; justify-content:space-between; align-items:center; background:var(--bg);">
              <div style="display:flex; align-items:center; gap:8px;">
                <span style="font-size:1.3rem;">📄</span>
                <h3 id="umw-viewer-title" style="margin:0; font-size:1.1rem; font-weight:800; color:var(--text);">معاينة المرفق</h3>
              </div>
              <div style="display:flex; gap:8px; align-items:center;">
                <a id="umw-viewer-download-btn" href="#" download class="btn btn-outline" style="padding:6px 12px; font-size:0.85rem; font-weight:700;">
                  ⬇️ تنزيل الملف
                </a>
                <button class="btn btn-outline" onclick="unifiedMyWorkManager.closeViewerModal()" style="padding:6px 12px; font-weight:800;">✕ إغلاق</button>
              </div>
            </div>
            <div id="umw-viewer-body" style="flex:1; overflow:auto; display:flex; align-items:center; justify-content:center; background:#0f172a; padding:10px;">
              <!-- Dynamic content: iframe for pdf, img for images, card for others -->
            </div>
          </div>
        </div>

        <!-- Unified Task Assignment & Edit Modal -->
        <div id="umw-task-modal" class="umw-modal-overlay" style="display:none; position:fixed; inset:0; background:rgba(15,23,42,0.8); backdrop-filter:blur(4px); z-index:9999; align-items:center; justify-content:center; padding:16px;">
          <div class="umw-modal-dialog" style="background:var(--bg-card); border:1px solid var(--border); border-radius:16px; width:min(880px, 95vw); max-height:92vh; display:flex; flex-direction:column; overflow:hidden; box-shadow:0 25px 50px -12px rgba(0,0,0,0.35);">
            <div style="padding:16px 22px; border-bottom:1px solid var(--border); display:flex; justify-content:space-between; align-items:center; background:var(--bg);">
              <h3 id="umw-task-modal-title" style="margin:0; font-size:1.15rem; font-weight:800; color:var(--text); display:flex; align-items:center; gap:8px;">
                <span>📋</span> <span>إسناد مهمة كشف ومعاينة فنية جديدة</span>
              </h3>
              <button class="btn btn-outline" onclick="unifiedMyWorkManager.closeTaskModal()" style="padding:4px 10px; font-size:1.1rem; border-radius:8px;">✕</button>
            </div>
            <div class="umw-modal-body" style="padding:22px; overflow-y:auto; flex:1;">
              <form id="umw-task-form" onsubmit="event.preventDefault(); unifiedMyWorkManager.saveTask();">
                <input type="hidden" id="task-id" />
                <div style="display:grid; grid-template-columns:repeat(auto-fit, minmax(240px, 1fr)); gap:14px; margin-bottom:14px;">
                  <div style="grid-column:1/-1;">
                    <label style="display:block; font-weight:700; margin-bottom:6px; font-size:0.88rem;">عنوان المهمة / الكشف الفني <span style="color:red">*</span></label>
                    <input type="text" id="task-title" required placeholder="مثال: كشف حسي على هبوط اسفلتي في شارع قلعة كفرنجة" style="width:100%; padding:10px 12px; border:1px solid var(--border); border-radius:8px; background:var(--bg); color:var(--text); font-size:0.9rem;" />
                  </div>
                  <div>
                    <label style="display:block; font-weight:700; margin-bottom:6px; font-size:0.88rem;">رقم الاستدعاء / المعاملة</label>
                    <input type="text" id="task-appeal-number" placeholder="مثال: 2026/45" style="width:100%; padding:9px 12px; border:1px solid var(--border); border-radius:8px; background:var(--bg); color:var(--text); font-size:0.88rem;" />
                  </div>
                  <div>
                    <label style="display:block; font-weight:700; margin-bottom:6px; font-size:0.88rem;">تاريخ الاستدعاء</label>
                    <input type="date" id="task-appeal-date" style="width:100%; padding:9px 12px; border:1px solid var(--border); border-radius:8px; background:var(--bg); color:var(--text); font-size:0.88rem;" />
                  </div>
                  <div>
                    <label style="display:block; font-weight:700; margin-bottom:6px; font-size:0.88rem;">اسم المواطن / المستدعي</label>
                    <input type="text" id="task-citizen-name" placeholder="اسم صاحب الطلب" style="width:100%; padding:9px 12px; border:1px solid var(--border); border-radius:8px; background:var(--bg); color:var(--text); font-size:0.88rem;" />
                  </div>
                  <div>
                    <label style="display:block; font-weight:700; margin-bottom:6px; font-size:0.88rem;">هاتف المواطن / التواصل</label>
                    <input type="text" id="task-citizen-phone" placeholder="07XXXXXXXX" style="width:100%; padding:9px 12px; border:1px solid var(--border); border-radius:8px; background:var(--bg); color:var(--text); font-size:0.88rem;" />
                  </div>
                  <div>
                    <label style="display:block; font-weight:700; margin-bottom:6px; font-size:0.88rem;">إسناد إلى المهندس / الفاحص <span style="color:red">*</span></label>
                    <select id="task-assigned-to" required style="width:100%; padding:9px 12px; border:1px solid var(--border); border-radius:8px; background:var(--bg); color:var(--text); font-size:0.88rem;">
                      <option value="">-- اختر المهندس المكلف --</option>
                    </select>
                  </div>
                  <div>
                    <label style="display:block; font-weight:700; margin-bottom:6px; font-size:0.88rem;">الأولوية</label>
                    <select id="task-priority" style="width:100%; padding:9px 12px; border:1px solid var(--border); border-radius:8px; background:var(--bg); color:var(--text); font-size:0.88rem;">
                      <option value="عادية">عادية</option>
                      <option value="متوسطة">متوسطة</option>
                      <option value="عالية">عالية ⚡</option>
                      <option value="حرجة">حرجة / طارئة 🚨</option>
                    </select>
                  </div>
                  <div>
                    <label style="display:block; font-weight:700; margin-bottom:6px; font-size:0.88rem;">تاريخ الاستحقاق والإنجاز</label>
                    <input type="date" id="task-due-date" style="width:100%; padding:9px 12px; border:1px solid var(--border); border-radius:8px; background:var(--bg); color:var(--text); font-size:0.88rem;" />
                  </div>
                  <div>
                    <label style="display:block; font-weight:700; margin-bottom:6px; font-size:0.88rem;">حالة المهمة</label>
                    <select id="task-status" style="width:100%; padding:9px 12px; border:1px solid var(--border); border-radius:8px; background:var(--bg); color:var(--text); font-size:0.88rem;">
                      <option value="واردة">واردة / بانتظار البدء</option>
                      <option value="قيد الكشف">قيد الكشف الفني</option>
                      <option value="مكتملة">مكتملة ومغلقة</option>
                      <option value="ملغاة">ملغاة</option>
                    </select>
                  </div>
                </div>

                <div style="margin-bottom:14px;">
                  <label style="display:block; font-weight:700; margin-bottom:6px; font-size:0.88rem;">تفاصيل ووصف المهمة والتوجيهات</label>
                  <textarea id="task-description" rows="3" placeholder="وصف وتفاصيل العمل المطلوب والكشف الميداني..." style="width:100%; padding:10px 12px; border:1px solid var(--border); border-radius:8px; background:var(--bg); color:var(--text); font-size:0.88rem;"></textarea>
                </div>

                <!-- Unified File Attachment Upload Zone -->
                <div style="background:var(--bg); border:1px dashed var(--primary); border-radius:10px; padding:14px; margin-bottom:16px;">
                  <label style="display:block; font-weight:700; margin-bottom:6px; font-size:0.88rem; color:var(--text);">📎 إرفاق ملف / استدعاء / صورة الموقع</label>
                  <div style="display:flex; gap:10px; align-items:center; flex-wrap:wrap;">
                    <input type="file" id="task-file-input" onchange="unifiedMyWorkManager.handleTaskFileSelect(this)" style="display:none;" />
                    <button type="button" class="btn btn-outline" onclick="document.getElementById('task-file-input').click()" style="display:flex; align-items:center; gap:6px;">
                      <span>📁</span> <span>اختيار ملف من الجهاز</span>
                    </button>
                    <span id="task-file-name-display" style="font-size:0.85rem; color:var(--text-muted);">لم يتم اختيار ملف</span>
                    <button type="button" id="btn-remove-task-file" onclick="unifiedMyWorkManager.clearTaskFile()" class="btn btn-outline" style="display:none; padding:2px 8px; color:var(--danger); border-color:var(--danger);">✕ حذف</button>
                  </div>
                  <div id="task-existing-file-box" style="margin-top:8px; display:none; font-size:0.85rem; background:var(--bg-card); padding:8px 12px; border-radius:6px; border:1px solid var(--border);">
                    <span>الملف المرفق حالياً: </span>
                    <a id="task-existing-file-link" href="#" target="_blank" style="font-weight:700; color:var(--primary);"></a>
                  </div>
                </div>

                <!-- Leaflet Location Picker with Unified GIS Engine Integration -->
                <div style="margin-bottom:14px;">
                  <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:6px;">
                    <label style="font-weight:700; font-size:0.88rem;">📍 تحديد الموقع الجغرافي على الخريطة (GIS)</label>
                    <span style="font-size:0.78rem; color:var(--text-muted);">انقر على الخريطة لتثبيت الدبوس</span>
                  </div>
                  <div id="umw-modal-map" style="height:240px; border-radius:10px; border:1px solid var(--border); z-index:1; overflow:hidden;"></div>
                  <div style="display:flex; gap:10px; margin-top:8px;">
                    <input type="text" id="task-lat" placeholder="خط العرض Lat" readonly style="flex:1; padding:6px 10px; border:1px solid var(--border); border-radius:6px; background:var(--bg); color:var(--text); font-size:0.8rem;" />
                    <input type="text" id="task-lng" placeholder="خط الطول Lng" readonly style="flex:1; padding:6px 10px; border:1px solid var(--border); border-radius:6px; background:var(--bg); color:var(--text); font-size:0.8rem;" />
                    <button type="button" class="btn btn-outline" onclick="unifiedMyWorkManager.resetModalMapPin()" style="font-size:0.8rem; padding:6px 10px;">إعادة ضبط</button>
                  </div>
                </div>

                <div style="display:flex; justify-content:flex-end; gap:10px; padding-top:14px; border-top:1px solid var(--border);">
                  <button type="button" class="btn btn-outline" onclick="unifiedMyWorkManager.closeTaskModal()">إلغاء</button>
                  <button type="submit" class="btn btn-primary" style="font-weight:800; padding:10px 24px;">💾 حفظ وإسناد المهمة</button>
                </div>
              </form>
            </div>
          </div>
        </div>

        <!-- Technical Report Submission Modal -->
        <div id="umw-report-modal" class="umw-modal-overlay" style="display:none; position:fixed; inset:0; background:rgba(15,23,42,0.8); backdrop-filter:blur(4px); z-index:9999; align-items:center; justify-content:center; padding:16px;">
          <div class="umw-modal-dialog" style="background:var(--bg-card); border:1px solid var(--border); border-radius:16px; width:min(880px, 95vw); max-height:92vh; display:flex; flex-direction:column; overflow:hidden; box-shadow:0 25px 50px -12px rgba(0,0,0,0.35);">
            <div style="padding:16px 22px; border-bottom:1px solid var(--border); display:flex; justify-content:space-between; align-items:center; background:var(--bg);">
              <h3 style="margin:0; font-size:1.15rem; font-weight:800; color:var(--text); display:flex; align-items:center; gap:8px;">
                <span>📝</span> <span>إعداد واعتماد تقرير الكشف الفني الميداني</span>
              </h3>
              <button class="btn btn-outline" onclick="unifiedMyWorkManager.closeReportModal()" style="padding:4px 10px; font-size:1.1rem; border-radius:8px;">✕</button>
            </div>
            <div class="umw-modal-body" style="padding:22px; overflow-y:auto; flex:1;">
              <form id="umw-report-form" onsubmit="event.preventDefault(); unifiedMyWorkManager.submitReport();">
                <input type="hidden" id="report-task-id" />
                <div id="report-task-summary" style="background:var(--bg); border-radius:10px; padding:12px 16px; margin-bottom:16px; border-right:4px solid var(--primary); font-size:0.88rem;"></div>

                <div style="margin-bottom:14px;">
                  <label style="display:block; font-weight:700; margin-bottom:6px; font-size:0.88rem;">نموذج الكشف الفني المعتمد</label>
                  <select id="report-template-select" onchange="unifiedMyWorkManager.applyReportTemplate(this.value)" style="width:100%; padding:10px 12px; border:1px solid var(--border); border-radius:8px; background:var(--bg); color:var(--text); font-size:0.88rem;">
                    <option value="">-- اختر قالباً فنياً جاهزاً --</option>
                    <option value="roads">🛣️ كشف سلامة طريق، حفر وتعبيد وتخسفات</option>
                    <option value="building">🏗️ كشف ترخيص، أبنية، جدران استنادية وعوائق</option>
                    <option value="water">💧 كشف شبكات تصريف مياه الأمطار والعبارات</option>
                    <option value="lighting">💡 كشف إنارة الشوارع ووحدات الطاقة</option>
                    <option value="general">📋 تقرير كشف ومعاينة هندسية عامة</option>
                  </select>
                </div>

                <div style="margin-bottom:14px;">
                  <label style="display:block; font-weight:700; margin-bottom:6px; font-size:0.88rem;">نص وتوصيات التقرير الفني الميداني <span style="color:red">*</span></label>
                  <textarea id="report-text" rows="8" required placeholder="اكتب نتائج المعاينة والتوصيات الفنية والحلول المقترحة..." style="width:100%; padding:12px; border:1px solid var(--border); border-radius:8px; background:var(--bg); color:var(--text); font-size:0.9rem; line-height:1.6;"></textarea>
                </div>

                <!-- Report Attachment File Zone -->
                <div style="background:var(--bg); border:1px dashed var(--success); border-radius:10px; padding:14px; margin-bottom:16px;">
                  <label style="display:block; font-weight:700; margin-bottom:6px; font-size:0.88rem; color:var(--text);">📎 إرفاق ملف التقرير الفني الموقع / صور المعاينة</label>
                  <div style="display:flex; gap:10px; align-items:center; flex-wrap:wrap;">
                    <input type="file" id="report-file-input" onchange="unifiedMyWorkManager.handleReportFileSelect(this)" style="display:none;" />
                    <button type="button" class="btn btn-outline" onclick="document.getElementById('report-file-input').click()" style="display:flex; align-items:center; gap:6px;">
                      <span>📷</span> <span>اختيار صورة / وثيقة PDF</span>
                    </button>
                    <span id="report-file-name-display" style="font-size:0.85rem; color:var(--text-muted);">لم يتم اختيار ملف</span>
                    <button type="button" id="btn-remove-report-file" onclick="unifiedMyWorkManager.clearReportFile()" class="btn btn-outline" style="display:none; padding:2px 8px; color:var(--danger); border-color:var(--danger);">✕ حذف</button>
                  </div>
                </div>

                <div style="display:flex; justify-content:flex-end; gap:10px; padding-top:14px; border-top:1px solid var(--border);">
                  <button type="button" class="btn btn-outline" onclick="unifiedMyWorkManager.closeReportModal()">إلغاء</button>
                  <button type="submit" class="btn btn-primary" style="font-weight:800; padding:10px 24px; background:var(--success); border-color:var(--success);">✅ اعتماد التقرير وإغلاق المهمة</button>
                </div>
              </form>
            </div>
          </div>
        </div>

        <!-- Task Details & Timeline Modal -->
        <div id="umw-details-modal" class="umw-modal-overlay" style="display:none; position:fixed; inset:0; background:rgba(15,23,42,0.8); backdrop-filter:blur(4px); z-index:9999; align-items:center; justify-content:center; padding:16px;">
          <div class="umw-modal-dialog" style="background:var(--bg-card); border:1px solid var(--border); border-radius:16px; width:min(880px, 95vw); max-height:92vh; display:flex; flex-direction:column; overflow:hidden; box-shadow:0 25px 50px -12px rgba(0,0,0,0.35);">
            <div style="padding:16px 22px; border-bottom:1px solid var(--border); display:flex; justify-content:space-between; align-items:center; background:var(--bg);">
              <h3 style="margin:0; font-size:1.15rem; font-weight:800; color:var(--text); display:flex; align-items:center; gap:8px;">
                <span>📄</span> <span id="umw-details-title">تفاصيل المهمة / الكشف</span>
              </h3>
              <div style="display:flex; gap:8px; align-items:center;">
                <button class="btn btn-outline" id="btn-print-task-details" onclick="unifiedMyWorkManager.printTaskCertificate()" style="font-weight:700; font-size:0.85rem;">🖨️ طباعة الشهادة</button>
                <button class="btn btn-outline" onclick="unifiedMyWorkManager.closeDetailsModal()" style="padding:4px 10px; font-size:1.1rem; border-radius:8px;">✕</button>
              </div>
            </div>
            <div class="umw-modal-body" id="umw-details-body" style="padding:22px; overflow-y:auto; flex:1;">
              <!-- Rendered dynamically -->
            </div>
          </div>
        </div>
      `;
    }

    async loadAllData() {
      this.isLoading = true;
      this.renderLoading();

      try {
        const [tasksRes, claimsRes, usersRes, tendersRes] = await Promise.all([
          apiFetch('/tasks', { silent: true }).catch(() => []),
          apiFetch('/claims', { silent: true }).catch(() => []),
          apiFetch('/users', { silent: true }).catch(() => []),
          apiFetch('/tenders', { silent: true }).catch(() => [])
        ]);

        this.tasks = Array.isArray(tasksRes) ? tasksRes : (tasksRes?.data || []);
        this.claims = Array.isArray(claimsRes) ? claimsRes : (claimsRes?.data || []);
        this.users = Array.isArray(usersRes) ? usersRes : (usersRes?.data || []);
        this.tenders = Array.isArray(tendersRes) ? tendersRes : (tendersRes?.data || []);
        this.workflowConfig = window._claimWorkflowConfig || [];

        this.populateUserSelects();
        this.updateKPIs();
        this.renderActiveTab();
      } catch (err) {
        console.error('Error loading My Work data:', err);
        const area = document.getElementById('umw-tab-content-area');
        if (area) {
          area.innerHTML = `
            <div style="text-align:center; padding:40px; color:var(--danger);">
              <div style="font-size:2rem; margin-bottom:10px;">⚠️</div>
              <p>حدث خطأ أثناء تحميل البيانات: ${err.message || 'خطأ غير معروف'}</p>
              <button class="btn btn-outline" onclick="unifiedMyWorkManager.loadAllData()" style="margin-top:10px;">إعادة المحاولة</button>
            </div>
          `;
        }
      } finally {
        this.isLoading = false;
      }
    }

    renderLoading() {
      const area = document.getElementById('umw-tab-content-area');
      if (area) {
        area.innerHTML = `
          <div style="text-align:center; padding:60px 20px; color:var(--text-muted);">
            <div class="spinner" style="margin:0 auto 15px auto;"></div>
            <p style="font-weight:600;">جارٍ استرجاع الأعمال الموكلة والمطالبات والكشوفات...</p>
          </div>
        `;
      }
    }

    populateUserSelects() {
      const select = document.getElementById('task-assigned-to');
      if (!select) return;
      
      const currentVal = select.value;
      select.innerHTML = '<option value="">-- اختر المهندس المكلف --</option>';
      
      this.users.forEach(u => {
        const opt = document.createElement('option');
        opt.value = u.id;
        opt.textContent = `${u.fullName || u.username} (${this.getRoleLabel(u.role)})`;
        select.appendChild(opt);
      });

      if (currentVal) select.value = currentVal;
    }

    getRoleLabel(role) {
      const map = {
        admin: 'مدير النظام',
        manager: 'مدير الأشغال',
        dept_head: 'رئيس قسم',
        engineer: 'مهندس مشاريع',
        inspector: 'مراقب كشف ميداني',
        auditor: 'مدقق مالي',
        employee: 'موظف'
      };
      return map[role] || role || 'مستخدم';
    }

    getMyActionableWork() {
      const myId = this.currentUser?.id;
      const myRole = this.currentUser?.role;
      const myName = this.currentUser?.fullName;

      // 1. Filter Claims waiting for my review
      const myClaims = this.claims.filter(c => {
        const status = c.status || '';
        if (status.includes('معتمدة') || status.includes('مرفوضة') || status.includes('ملغاة')) return false;

        if (this.workflowConfig.length > 0) {
          const steps = ['مسودة', ...this.workflowConfig.map(s => s.label), 'معتمدة وجاهزة للصرف'];
          const currentIdx = status.includes('مسودة') ? 0 : steps.indexOf(status);
          if (currentIdx > 0 && currentIdx < steps.length - 1) {
            const stepConf = this.workflowConfig[currentIdx - 1];
            if (stepConf && (stepConf.userId === myId || stepConf.userId === myRole || myRole === 'admin')) {
              return true;
            }
          }
        } else {
          if (status === 'بانتظار تدقيق رئيس القسم' && (myRole === 'dept_head' || myRole === 'admin')) return true;
          if (status === 'بانتظار تدقيق المدير' && (myRole === 'manager' || myRole === 'admin')) return true;
        }
        return false;
      });

      // 2. Filter Tasks assigned to me
      const myTasks = this.tasks.filter(t => {
        if (t.status === 'مكتملة' || t.status === 'ملغاة') return false;
        return (t.assignedTo === myId || t.assignedTo === myRole || t.assignedTo === myName || (t.assignedToName && t.assignedToName === myName));
      });

      return { myClaims, myTasks };
    }

    getSentWork() {
      const myId = this.currentUser?.id;
      const myName = this.currentUser?.fullName;

      const sentClaims = this.claims.filter(c => {
        const isSentByMe = (c.createdBy === myId || (c.history && c.history.includes(myName)));
        const isPending = !((c.status || '').includes('معتمدة') || (c.status || '').includes('مرفوضة'));
        return isSentByMe && isPending;
      });

      const sentTasks = this.tasks.filter(t => {
        const isSentByMe = (t.assignedBy === myId || t.assignedByName === myName || t.assignedBy === 'admin');
        const isPending = t.status !== 'مكتملة' && t.status !== 'ملغاة';
        return isSentByMe && isPending;
      });

      return { sentClaims, sentTasks };
    }

    updateKPIs() {
      const { myClaims, myTasks } = this.getMyActionableWork();
      const { sentClaims, sentTasks } = this.getSentWork();

      const totalActionable = myClaims.length + myTasks.length;
      const totalSent = sentClaims.length + sentTasks.length;
      const completedTasks = this.tasks.filter(t => t.status === 'مكتملة').length;
      
      const todayStr = new Date().toISOString().split('T')[0];
      const overdueTasks = this.tasks.filter(t => t.dueDate && t.dueDate < todayStr && t.status !== 'مكتملة' && t.status !== 'ملغاة').length;

      const setEl = (id, val) => { const el = document.getElementById(id); if (el) el.textContent = val; };

      setEl('kpi-my-actionable', totalActionable);
      setEl('kpi-my-claims', myClaims.length);
      setEl('kpi-my-tasks', myTasks.length);
      setEl('kpi-my-sent', totalSent);
      setEl('kpi-completed-tasks', completedTasks);
      setEl('kpi-overdue-tasks', overdueTasks);

      setEl('badge-tab-mine', totalActionable);
      setEl('badge-tab-sent', totalSent);
      setEl('badge-tab-registry', this.tasks.length);

      // Global navbar badge update
      const bNav = document.getElementById('badge-my-work');
      if (bNav) bNav.textContent = totalActionable || this.tasks.length;
    }

    switchTab(tabName) {
      this.activeTab = tabName;
      document.querySelectorAll('.mw-tab-nav').forEach(btn => {
        btn.classList.remove('active');
        btn.style.background = 'transparent';
        btn.style.color = 'var(--text-muted)';
        btn.style.borderBottom = '3px solid transparent';
      });

      const activeBtn = document.getElementById(`tab-btn-${tabName}`);
      if (activeBtn) {
        activeBtn.classList.add('active');
        activeBtn.style.color = 'var(--primary)';
        activeBtn.style.borderBottom = '3px solid var(--primary)';
      }

      this.renderActiveTab();
    }

    renderActiveTab() {
      const area = document.getElementById('umw-tab-content-area');
      if (!area) return;

      if (this.activeTab === 'mine') {
        this.renderMineTab(area);
      } else if (this.activeTab === 'sent') {
        this.renderSentTab(area);
      } else if (this.activeTab === 'registry') {
        this.renderRegistryTab(area);
      } else if (this.activeTab === 'department') {
        this.renderDepartmentTab(area);
      }
    }

    // ─────────────────────────────────────────────────────────────────────────────
    // TAB 1: أعمالي الموكلة بانتظاري (My Actionable Work)
    // ─────────────────────────────────────────────────────────────────────────────
    renderMineTab(container) {
      const { myClaims, myTasks } = this.getMyActionableWork();

      let filteredClaims = myClaims;
      let filteredTasks = myTasks;

      if (this.myWorkFilter === 'claims') filteredTasks = [];
      if (this.myWorkFilter === 'tasks') filteredClaims = [];

      const totalItems = filteredClaims.length + filteredTasks.length;

      container.innerHTML = `
        <div style="animation:fadeIn 0.2s ease;">
          <!-- Quick Filter Pills -->
          <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:10px; margin-bottom:16px;">
            <div style="display:flex; gap:8px; align-items:center;">
              <button class="btn ${this.myWorkFilter === 'all' ? 'btn-primary' : 'btn-outline'}" onclick="unifiedMyWorkManager.setMyWorkFilter('all')" style="font-size:0.84rem; padding:6px 14px;">
                الكل (${myClaims.length + myTasks.length})
              </button>
              <button class="btn ${this.myWorkFilter === 'claims' ? 'btn-primary' : 'btn-outline'}" onclick="unifiedMyWorkManager.setMyWorkFilter('claims')" style="font-size:0.84rem; padding:6px 14px;">
                📝 مطالبات مالية (${myClaims.length})
              </button>
              <button class="btn ${this.myWorkFilter === 'tasks' ? 'btn-primary' : 'btn-outline'}" onclick="unifiedMyWorkManager.setMyWorkFilter('tasks')" style="font-size:0.84rem; padding:6px 14px;">
                📋 مهام وكشوفات فنية (${myTasks.length})
              </button>
            </div>
            <div style="font-size:0.85rem; color:var(--text-muted);">
              إجمالي الأعمال بانتظار إجرائك: <strong>${totalItems}</strong> معاملة
            </div>
          </div>

          ${totalItems === 0 ? `
            <div style="text-align:center; padding:60px 20px; background:var(--bg-card); border-radius:14px; border:1px dashed var(--border);">
              <div style="font-size:3rem; margin-bottom:12px;">🎉</div>
              <h3 style="margin:0 0 6px 0; color:var(--text);">رائع! لا توجد معاملات معلقة بانتظارك حالياً</h3>
              <p style="color:var(--text-muted); font-size:0.9rem; margin:0;">لقد قمت بإنجاز كافة المطالبات والمهام المسندة إليك بنجاح.</p>
            </div>
          ` : `
            <div style="display:grid; grid-template-columns:repeat(auto-fill, minmax(340px, 1fr)); gap:16px;">
              ${filteredClaims.map(c => this.renderClaimCard(c, 'primary')).join('')}
              ${filteredTasks.map(t => this.renderTaskCard(t, 'mine')).join('')}
            </div>
          `}
        </div>
      `;
    }

    setMyWorkFilter(filter) {
      this.myWorkFilter = filter;
      this.renderActiveTab();
    }

    // ─────────────────────────────────────────────────────────────────────────────
    // TAB 2: أعمال قمت بإسنادها ومتابعتها (Delegated Work)
    // ─────────────────────────────────────────────────────────────────────────────
    renderSentTab(container) {
      const { sentClaims, sentTasks } = this.getSentWork();
      const totalSent = sentClaims.length + sentTasks.length;

      container.innerHTML = `
        <div style="animation:fadeIn 0.2s ease;">
          <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:16px;">
            <h3 style="margin:0; font-size:1.05rem; font-weight:700; color:var(--text);">
              📤 قائمة المعاملات والمهام المحولة للآخرين قيد المتابعة والإنجاز
            </h3>
            <span style="font-size:0.85rem; color:var(--text-muted);">إجمالي المعاملات الصادرة: <strong>${totalSent}</strong></span>
          </div>

          ${totalSent === 0 ? `
            <div style="text-align:center; padding:50px 20px; background:var(--bg-card); border-radius:14px; border:1px dashed var(--border);">
              <div style="font-size:2.5rem; margin-bottom:10px;">📭</div>
              <p style="color:var(--text-muted); font-size:0.9rem; margin:0;">لا توجد معاملات أو مهام قمت بتحويلها بانتظار الإنجاز حالياً.</p>
            </div>
          ` : `
            <div style="display:grid; grid-template-columns:repeat(auto-fill, minmax(340px, 1fr)); gap:16px;">
              ${sentClaims.map(c => this.renderClaimCard(c, 'accent', true)).join('')}
              ${sentTasks.map(t => this.renderTaskCard(t, 'sent')).join('')}
            </div>
          `}
        </div>
      `;
    }

    // ─────────────────────────────────────────────────────────────────────────────
    // TAB 3: سجل الكشوفات والمهام الشامل (All Department Tasks)
    // ─────────────────────────────────────────────────────────────────────────────
    renderRegistryTab(container) {
      let filtered = this.tasks.filter(t => {
        if (this.searchTerm) {
          const s = this.searchTerm.toLowerCase();
          const matchTitle = (t.title || '').toLowerCase().includes(s);
          const matchCitizen = (t.citizenName || '').toLowerCase().includes(s);
          const matchAppeal = (t.appealNumber || '').toLowerCase().includes(s);
          const matchId = (t.id || '').toLowerCase().includes(s);
          if (!matchTitle && !matchCitizen && !matchAppeal && !matchId) return false;
        }
        if (this.statusFilter && t.status !== this.statusFilter) return false;
        if (this.priorityFilter && t.priority !== this.priorityFilter) return false;
        if (this.assigneeFilter && t.assignedTo !== this.assigneeFilter) return false;
        return true;
      });

      container.innerHTML = `
        <div style="animation:fadeIn 0.2s ease;">
          <!-- View Mode Switcher & Filter Toolbar -->
          <div style="background:var(--bg-card); border:1px solid var(--border); border-radius:12px; padding:14px; margin-bottom:16px; box-shadow:0 2px 8px rgba(0,0,0,0.02);">
            <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:10px; margin-bottom:12px;">
              <div style="display:flex; gap:8px;">
                <button class="btn ${this.viewMode === 'table' ? 'btn-primary' : 'btn-outline'}" onclick="unifiedMyWorkManager.setViewMode('table')" style="font-size:0.85rem; padding:6px 12px; display:flex; align-items:center; gap:5px;">
                  <span>📄</span> <span>جدول البيانات</span>
                </button>
                <button class="btn ${this.viewMode === 'kanban' ? 'btn-primary' : 'btn-outline'}" onclick="unifiedMyWorkManager.setViewMode('kanban')" style="font-size:0.85rem; padding:6px 12px; display:flex; align-items:center; gap:5px;">
                  <span>📋</span> <span>لوحة الإنجاز (Kanban)</span>
                </button>
                <button class="btn ${this.viewMode === 'map' ? 'btn-primary' : 'btn-outline'}" onclick="unifiedMyWorkManager.setViewMode('map')" style="font-size:0.85rem; padding:6px 12px; display:flex; align-items:center; gap:5px;">
                  <span>🗺️</span> <span>خريطة المهام (GIS)</span>
                </button>
              </div>

              ${this.isManagerOrAdmin() ? `
                <button class="btn btn-primary" onclick="unifiedMyWorkManager.openTaskModal()" style="font-size:0.85rem; padding:6px 14px;">
                  + إسناد مهمة كشف جديدة
                </button>
              ` : ''}
            </div>

            <!-- Filters Row -->
            <div style="display:grid; grid-template-columns: 2fr 1fr 1fr 1fr auto; gap:10px; align-items:center;">
              <input type="text" placeholder="🔍 بحث بالعنوان، رقم الاستدعاء، اسم المواطن أو رقم المهمة..." 
                value="${this.searchTerm}"
                oninput="unifiedMyWorkManager.onSearchChange(this.value)"
                style="padding:8px 12px; border:1px solid var(--border); border-radius:8px; background:var(--bg); color:var(--text); font-size:0.85rem;" />

              <select onchange="unifiedMyWorkManager.onStatusFilterChange(this.value)" style="padding:8px 10px; border:1px solid var(--border); border-radius:8px; background:var(--bg); color:var(--text); font-size:0.85rem;">
                <option value="">جميع الحالات</option>
                <option value="واردة" ${this.statusFilter === 'واردة' ? 'selected' : ''}>📥 واردة</option>
                <option value="قيد الكشف" ${this.statusFilter === 'قيد الكشف' ? 'selected' : ''}>⏳ قيد الكشف الفني</option>
                <option value="مكتملة" ${this.statusFilter === 'مكتملة' ? 'selected' : ''}>✅ مكتملة ومغلقة</option>
                <option value="ملغاة" ${this.statusFilter === 'ملغاة' ? 'selected' : ''}>❌ ملغاة</option>
              </select>

              <select onchange="unifiedMyWorkManager.onPriorityFilterChange(this.value)" style="padding:8px 10px; border:1px solid var(--border); border-radius:8px; background:var(--bg); color:var(--text); font-size:0.85rem;">
                <option value="">جميع الأولويات</option>
                <option value="عادية" ${this.priorityFilter === 'عادية' ? 'selected' : ''}>عادية</option>
                <option value="متوسطة" ${this.priorityFilter === 'متوسطة' ? 'selected' : ''}>متوسطة</option>
                <option value="عالية" ${this.priorityFilter === 'عالية' ? 'selected' : ''}>عالية ⚡</option>
                <option value="حرجة" ${this.priorityFilter === 'حرجة' ? 'selected' : ''}>حرجة 🚨</option>
              </select>

              <select onchange="unifiedMyWorkManager.onAssigneeFilterChange(this.value)" style="padding:8px 10px; border:1px solid var(--border); border-radius:8px; background:var(--bg); color:var(--text); font-size:0.85rem;">
                <option value="">المهام المسندة للجميع</option>
                ${this.users.map(u => `<option value="${u.id}" ${this.assigneeFilter === u.id ? 'selected' : ''}>مسندة إلى: ${u.fullName || u.username}</option>`).join('')}
              </select>

              <button class="btn btn-outline" onclick="unifiedMyWorkManager.resetFilters()" title="إعادة ضبط الفلاتر" style="padding:8px 12px; font-size:0.85rem;">
                🔄 تفريغ
              </button>
            </div>
          </div>

          <!-- Active View Container -->
          <div id="umw-registry-view-container">
            ${this.renderRegistryViewMode(filtered)}
          </div>
        </div>
      `;

      if (this.viewMode === 'map') {
        setTimeout(() => this.initGISMap(filtered), 150);
      }
    }

    renderRegistryViewMode(data) {
      if (this.viewMode === 'table') {
        return this.renderTableView(data);
      } else if (this.viewMode === 'kanban') {
        return this.renderKanbanView(data);
      } else if (this.viewMode === 'map') {
        return `
          <div style="background:var(--bg-card); border:1px solid var(--border); border-radius:12px; padding:10px; overflow:hidden; box-shadow:0 2px 8px rgba(0,0,0,0.02);">
            <div id="tasks-gis-overview-map" style="width:100%; min-height:500px; height:clamp(500px, 60vh, 700px); border-radius:8px; z-index:1;"></div>
          </div>
        `;
      }
    }

    renderTableView(data) {
      if (!data.length) {
        return `
          <div style="text-align:center; padding:50px 20px; background:var(--bg-card); border-radius:12px; border:1px dashed var(--border);">
            <div style="font-size:2.5rem; margin-bottom:8px;">📭</div>
            <p style="color:var(--text-muted); font-size:0.9rem; margin:0;">لا توجد مهام أو كشوفات مطابقة لمعايير البحث</p>
          </div>
        `;
      }

      return `
        <div class="table-container" style="background:var(--bg-card); border:1px solid var(--border); border-radius:12px; overflow-x:auto; width:100%; box-shadow:0 2px 10px rgba(0,0,0,0.02);">
          <table class="data-table" style="width:100%; border-collapse:collapse; text-align:right; min-width:850px;">
            <thead>
              <tr style="background:var(--bg); border-bottom:2px solid var(--border);">
                <th style="padding:12px 14px; font-weight:800; font-size:0.84rem; color:var(--text);">رقم المهمة</th>
                <th style="padding:12px 14px; font-weight:800; font-size:0.84rem; color:var(--text);">العنوان وبيان الكشف</th>
                <th style="padding:12px 14px; font-weight:800; font-size:0.84rem; color:var(--text);">المواطن / الاستدعاء</th>
                <th style="padding:12px 14px; font-weight:800; font-size:0.84rem; color:var(--text);">المهندس المكلف</th>
                <th style="padding:12px 14px; font-weight:800; font-size:0.84rem; color:var(--text);">الأولوية</th>
                <th style="padding:12px 14px; font-weight:800; font-size:0.84rem; color:var(--text);">الحالة</th>
                <th style="padding:12px 14px; font-weight:800; font-size:0.84rem; color:var(--text);">المرفقات</th>
                <th style="padding:12px 14px; font-weight:800; font-size:0.84rem; color:var(--text); text-align:center;">الإجراءات</th>
              </tr>
            </thead>
            <tbody>
              ${data.map(t => {
                const prColor = this.getPriorityColor(t.priority);
                const stColor = this.getStatusColor(t.status);
                const attachedFile = t.reportFile || t.reportfile || t.file || t.attachmentPath || '';

                return `
                  <tr style="border-bottom:1px solid var(--border); transition:background 0.15s;" onmouseover="this.style.background='rgba(0,0,0,0.02)'" onmouseout="this.style.background='transparent'">
                    <td style="padding:12px 14px; font-weight:800; font-family:monospace; color:var(--primary);">
                      ${t.id}
                    </td>
                    <td style="padding:12px 14px;">
                      <div style="font-weight:700; color:var(--text);">${t.title}</div>
                      <div style="font-size:0.78rem; color:var(--text-muted); margin-top:2px;">الاستحقاق: ${t.dueDate || 'غير محدد'}</div>
                    </td>
                    <td style="padding:12px 14px; font-size:0.85rem;">
                      <div>${t.citizenName || '-'}</div>
                      <div style="font-size:0.75rem; color:var(--text-muted);">${t.appealNumber ? `استدعاء: ${t.appealNumber}` : ''}</div>
                    </td>
                    <td style="padding:12px 14px; font-size:0.85rem;">
                      <strong>${t.assignedToName || t.assignedTo || '-'}</strong>
                    </td>
                    <td style="padding:12px 14px;">
                      <span class="badge" style="background:${prColor}; color:#fff; font-size:0.75rem; padding:3px 8px; border-radius:6px;">${t.priority || 'عادية'}</span>
                    </td>
                    <td style="padding:12px 14px;">
                      <span class="badge" style="background:${stColor}; color:#fff; font-size:0.75rem; padding:3px 8px; border-radius:6px;">${t.status || 'واردة'}</span>
                    </td>
                    <td style="padding:12px 14px;">
                      ${attachedFile ? `
                        <button class="btn btn-outline" onclick="unifiedMyWorkManager.openAttachmentViewer('/uploads/${attachedFile}', 'مرفق المهمة (${t.id})')" style="padding:3px 8px; font-size:0.75rem; display:flex; align-items:center; gap:4px;" title="معاينة الملف">
                          <span>📎</span> <span>معاينة</span>
                        </button>
                      ` : '<span style="color:var(--text-muted); font-size:0.75rem;">لا يوجد</span>'}
                    </td>
                    <td style="padding:12px 14px; text-align:center;">
                      <div style="display:inline-flex; gap:6px; align-items:center;">
                        <button class="btn btn-outline" onclick="unifiedMyWorkManager.openDetailsModal('${t.id}')" title="عرض التفاصيل" style="padding:4px 8px; font-size:0.8rem;">
                          👁️
                        </button>
                        ${(this.isManagerOrAdmin() || this.currentUser?.id === t.assignedTo) && t.status !== 'مكتملة' ? `
                          <button class="btn btn-primary" onclick="unifiedMyWorkManager.openReportModal('${t.id}')" style="padding:4px 8px; font-size:0.78rem; font-weight:700;">
                            📝 التقرير
                          </button>
                        ` : ''}
                        ${this.isManagerOrAdmin() ? `
                          <button class="btn btn-outline" onclick="unifiedMyWorkManager.openTaskModal('${t.id}')" title="تعديل المهمة" style="padding:4px 8px; font-size:0.8rem;">
                            ✏️
                          </button>
                          <button class="btn btn-danger" onclick="unifiedMyWorkManager.deleteTask('${t.id}')" title="حذف المهمة" style="padding:4px 8px; font-size:0.8rem;">
                            🗑️
                          </button>
                        ` : ''}
                      </div>
                    </td>
                  </tr>
                `;
              }).join('')}
            </tbody>
          </table>
          <div style="padding:10px 14px; background:var(--bg); border-top:1px solid var(--border); font-size:0.82rem; color:var(--text-muted); display:flex; justify-content:space-between;">
            <span>عدد المهام المعروضة: <strong>${data.length}</strong> مهمة</span>
            <span>مديرية الأشغال والخدمات الهندسية</span>
          </div>
        </div>
      `;
    }

    renderKanbanView(data) {
      const colNew = data.filter(t => t.status === 'واردة');
      const colPending = data.filter(t => t.status === 'قيد الكشف');
      const colCompleted = data.filter(t => t.status === 'مكتملة');

      return `
        <div style="display:grid; grid-template-columns:repeat(auto-fit, minmax(300px, 1fr)); gap:16px;">
          <!-- Column 1: واردة -->
          <div style="background:var(--bg-card); border:1px solid var(--border); border-radius:12px; overflow:hidden; display:flex; flex-direction:column; box-shadow:0 2px 8px rgba(0,0,0,0.02);">
            <div style="padding:12px 16px; background:rgba(2,132,199,0.08); border-bottom:2px solid var(--primary); display:flex; justify-content:space-between; align-items:center;">
              <div style="font-weight:800; color:var(--primary); font-size:0.95rem;">📥 مهام واردة وبانتظار البدء</div>
              <span class="badge" style="background:var(--primary); color:#fff; border-radius:10px; padding:2px 8px; font-size:0.75rem;">${colNew.length}</span>
            </div>
            <div style="padding:12px; flex:1; overflow-y:auto; max-height:70vh; display:flex; flex-direction:column; gap:10px;">
              ${colNew.length ? colNew.map(t => this.renderKanbanCard(t)).join('') : '<div style="text-align:center; padding:30px; color:var(--text-muted); font-size:0.85rem;">لا توجد مهام واردة</div>'}
            </div>
          </div>

          <!-- Column 2: قيد الكشف الفني -->
          <div style="background:var(--bg-card); border:1px solid var(--border); border-radius:12px; overflow:hidden; display:flex; flex-direction:column; box-shadow:0 2px 8px rgba(0,0,0,0.02);">
            <div style="padding:12px 16px; background:rgba(245,158,11,0.08); border-bottom:2px solid #f59e0b; display:flex; justify-content:space-between; align-items:center;">
              <div style="font-weight:800; color:#f59e0b; font-size:0.95rem;">⏳ قيد الكشف والمعاينة الفنية</div>
              <span class="badge" style="background:#f59e0b; color:#fff; border-radius:10px; padding:2px 8px; font-size:0.75rem;">${colPending.length}</span>
            </div>
            <div style="padding:12px; flex:1; overflow-y:auto; max-height:70vh; display:flex; flex-direction:column; gap:10px;">
              ${colPending.length ? colPending.map(t => this.renderKanbanCard(t)).join('') : '<div style="text-align:center; padding:30px; color:var(--text-muted); font-size:0.85rem;">لا توجد مهام قيد الكشف</div>'}
            </div>
          </div>

          <!-- Column 3: مكتملة ومغلقة -->
          <div style="background:var(--bg-card); border:1px solid var(--border); border-radius:12px; overflow:hidden; display:flex; flex-direction:column; box-shadow:0 2px 8px rgba(0,0,0,0.02);">
            <div style="padding:12px 16px; background:rgba(16,185,129,0.08); border-bottom:2px solid var(--success); display:flex; justify-content:space-between; align-items:center;">
              <div style="font-weight:800; color:var(--success); font-size:0.95rem;">✅ تم إعداد التقرير وإغلاقها</div>
              <span class="badge" style="background:var(--success); color:#fff; border-radius:10px; padding:2px 8px; font-size:0.75rem;">${colCompleted.length}</span>
            </div>
            <div style="padding:12px; flex:1; overflow-y:auto; max-height:70vh; display:flex; flex-direction:column; gap:10px;">
              ${colCompleted.length ? colCompleted.map(t => this.renderKanbanCard(t)).join('') : '<div style="text-align:center; padding:30px; color:var(--text-muted); font-size:0.85rem;">لا توجد مهام مكتملة</div>'}
            </div>
          </div>
        </div>
      `;
    }

    renderKanbanCard(t) {
      const prColor = this.getPriorityColor(t.priority);
      const attachedFile = t.reportFile || t.reportfile || t.file || t.attachmentPath || '';

      return `
        <div style="background:var(--bg); border:1px solid var(--border); border-radius:10px; padding:12px; box-shadow:0 2px 6px rgba(0,0,0,0.03); display:flex; flex-direction:column; gap:8px;">
          <div style="display:flex; justify-content:space-between; align-items:center;">
            <span style="font-weight:800; font-family:monospace; font-size:0.8rem; color:var(--primary);">${t.id}</span>
            <span class="badge" style="background:${prColor}; color:#fff; font-size:0.7rem; padding:2px 6px; border-radius:4px;">${t.priority || 'عادية'}</span>
          </div>
          <div style="font-weight:700; font-size:0.88rem; color:var(--text); line-height:1.4;">${t.title}</div>
          <div style="font-size:0.78rem; color:var(--text-muted);">
            <div>👤 المواطن: ${t.citizenName || '-'}</div>
            <div>👷 المكلف: <strong>${t.assignedToName || t.assignedTo || '-'}</strong></div>
          </div>
          <div style="display:flex; justify-content:space-between; align-items:center; border-top:1px solid var(--border); padding-top:8px; margin-top:2px;">
            <span style="font-size:0.74rem; color:var(--text-muted);">📅 ${t.dueDate || 'بدون موعد'}</span>
            <div style="display:flex; gap:4px;">
              ${attachedFile ? `
                <button class="btn btn-outline" onclick="unifiedMyWorkManager.openAttachmentViewer('/uploads/${attachedFile}', 'مرفق المهمة (${t.id})')" style="padding:2px 6px; font-size:0.75rem;" title="معاينة المرفق">📎</button>
              ` : ''}
              <button class="btn btn-outline" onclick="unifiedMyWorkManager.openDetailsModal('${t.id}')" style="padding:2px 6px; font-size:0.75rem;">👁️ تفاصيل</button>
              ${(this.isManagerOrAdmin() || this.currentUser?.id === t.assignedTo) && t.status !== 'مكتملة' ? `
                <button class="btn btn-primary" onclick="unifiedMyWorkManager.openReportModal('${t.id}')" style="padding:2px 6px; font-size:0.75rem;">📝</button>
              ` : ''}
            </div>
          </div>
        </div>
      `;
    }

    initGISMap(tasks) {
      const mapEl = document.getElementById('tasks-gis-overview-map');
      if (!mapEl || typeof L === 'undefined') return;

      if (this.mapInstance) {
        this.mapInstance.remove();
        this.mapInstance = null;
      }

      const defaultCenter = [32.2985, 35.7050]; // مركز بلدية كفرنجة الجديدة
      
      // Integration with Unified GIS Engine
      if (typeof UnifiedGisEngine !== 'undefined' && typeof UnifiedGisEngine.createMap === 'function') {
        this.mapInstance = UnifiedGisEngine.createMap('tasks-gis-overview-map', defaultCenter, 14);
      } else {
        const streetLayer = L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Street_Map/MapServer/tile/{z}/{y}/{x}', { maxZoom: 19, attribution: '&copy; Esri World Street' });
        const satLayer = L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}', { maxZoom: 19, attribution: '&copy; Esri World Imagery HD' });
        const osmLayer = L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', { maxZoom: 19, attribution: '&copy; OpenStreetMap' });

        this.mapInstance = L.map('tasks-gis-overview-map', {
          center: defaultCenter,
          zoom: 14,
          layers: [streetLayer]
        });

        L.control.layers({
          '🛣️ خريطة الشوارع والملاحة (Esri Street)': streetLayer,
          '🛰️ صور الأقمار الصناعية (Esri Satellite)': satLayer,
          '🌐 خريطة الشوارع العامة (OSM)': osmLayer
        }).addTo(this.mapInstance);
      }

      const bounds = L.latLngBounds();
      let hasPins = false;

      tasks.forEach(t => {
        const lat = parseFloat(t.lat);
        const lng = parseFloat(t.lng);
        if (lat && lng && !isNaN(lat) && !isNaN(lng)) {
          hasPins = true;
          const latlng = [lat, lng];
          bounds.extend(latlng);

          const color = t.status === 'مكتملة' ? '#10b981' : (t.status === 'قيد الكشف' ? '#f59e0b' : '#0284c7');
          const markerIcon = L.divIcon({
            className: 'custom-map-marker',
            html: `
              <div style="background:${color}; width:24px; height:24px; border-radius:50%; border:3px solid #fff; box-shadow:0 3px 8px rgba(0,0,0,0.4); display:flex; align-items:center; justify-content:center; color:#fff; font-size:11px; font-weight:800;">
                📍
              </div>
            `,
            iconSize: [24, 24],
            iconAnchor: [12, 12]
          });

          const marker = L.marker(latlng, { icon: markerIcon }).addTo(this.mapInstance);
          marker.bindPopup(`
            <div style="font-family:'Tajawal',sans-serif; text-align:right; min-width:200px;" dir="rtl">
              <div style="font-weight:800; color:#0284c7; margin-bottom:4px;">${t.id}: ${t.title}</div>
              <div style="font-size:0.8rem; color:#475569; margin-bottom:4px;">👤 المواطن: ${t.citizenName || '-'}</div>
              <div style="font-size:0.8rem; color:#475569; margin-bottom:6px;">👷 المكلف: ${t.assignedToName || t.assignedTo || '-'}</div>
              <div style="display:flex; justify-content:space-between; align-items:center;">
                <span class="badge" style="background:${color}; color:#fff; font-size:0.7rem;">${t.status}</span>
                <button onclick="unifiedMyWorkManager.openDetailsModal('${t.id}')" style="background:#0284c7; color:#fff; border:none; border-radius:4px; padding:3px 8px; font-size:0.75rem; cursor:pointer;">التفاصيل</button>
              </div>
            </div>
          `);
        }
      });

      if (hasPins) {
        this.mapInstance.fitBounds(bounds, { padding: [40, 40] });
      }

      setTimeout(() => {
        if (this.mapInstance) this.mapInstance.invalidateSize();
      }, 300);
    }

    // ─────────────────────────────────────────────────────────────────────────────
    // TAB 4: متابعة أعمال القسم والكوادر (Department Overview - Managers)
    // ─────────────────────────────────────────────────────────────────────────────
    renderDepartmentTab(container) {
      if (!this.isManagerOrAdmin()) {
        container.innerHTML = `<div style="text-align:center; padding:40px; color:var(--danger);">غير مصرح لك بعرض هذه اللوحة</div>`;
        return;
      }

      // Group tasks by assignee
      const staffStats = {};
      this.users.forEach(u => {
        staffStats[u.id] = {
          id: u.id,
          name: u.fullName || u.username,
          role: this.getRoleLabel(u.role),
          total: 0,
          pending: 0,
          completed: 0,
          overdue: 0
        };
      });

      const todayStr = new Date().toISOString().split('T')[0];

      this.tasks.forEach(t => {
        const uId = t.assignedTo;
        if (staffStats[uId]) {
          staffStats[uId].total++;
          if (t.status === 'مكتملة') staffStats[uId].completed++;
          else staffStats[uId].pending++;

          if (t.dueDate && t.dueDate < todayStr && t.status !== 'مكتملة' && t.status !== 'ملغاة') {
            staffStats[uId].overdue++;
          }
        }
      });

      const activeStaff = Object.values(staffStats).filter(s => s.total > 0 || ['engineer', 'inspector'].includes(s.id));

      container.innerHTML = `
        <div style="animation:fadeIn 0.2s ease;">
          <div style="margin-bottom:16px;">
            <h3 style="margin:0 0 4px 0; font-size:1.1rem; font-weight:800; color:var(--text);">
              👥 لوحة متابعة إنجاز الكوادر الهندسية والفنية
            </h3>
            <p style="color:var(--text-muted); font-size:0.85rem; margin:0;">
              رصد مؤشرات الأداء، نسب الإنجاز، والمعاملات المتأخرة لكافة موظفي المديرية
            </p>
          </div>

          <div style="display:grid; grid-template-columns:repeat(auto-fit, minmax(280px, 1fr)); gap:16px;">
            ${activeStaff.map(s => {
              const rate = s.total > 0 ? Math.round((s.completed / s.total) * 100) : 0;
              return `
                <div style="background:var(--bg-card); border:1px solid var(--border); border-radius:12px; padding:16px; box-shadow:0 2px 8px rgba(0,0,0,0.02); display:flex; flex-direction:column; gap:10px;">
                  <div style="display:flex; justify-content:space-between; align-items:flex-start;">
                    <div>
                      <h4 style="margin:0; font-size:0.95rem; font-weight:800; color:var(--text);">${s.name}</h4>
                      <span style="font-size:0.75rem; color:var(--text-muted);">${s.role}</span>
                    </div>
                    <button class="btn btn-outline" onclick="unifiedMyWorkManager.pingUser('${s.id}', '${s.name}')" style="padding:4px 8px; font-size:0.75rem;" title="إرسال تنبيه متابعة">
                      🔔 تذكير
                    </button>
                  </div>

                  <div style="display:grid; grid-template-columns:repeat(3, 1fr); gap:8px; text-align:center; background:var(--bg); padding:10px; border-radius:8px;">
                    <div>
                      <div style="font-size:0.75rem; color:var(--text-muted);">المسندة</div>
                      <div style="font-weight:800; font-size:1.1rem; color:var(--primary);">${s.total}</div>
                    </div>
                    <div>
                      <div style="font-size:0.75rem; color:var(--text-muted);">قيد الإجراء</div>
                      <div style="font-weight:800; font-size:1.1rem; color:#f59e0b;">${s.pending}</div>
                    </div>
                    <div>
                      <div style="font-size:0.75rem; color:var(--text-muted);">المنجزة</div>
                      <div style="font-weight:800; font-size:1.1rem; color:var(--success);">${s.completed}</div>
                    </div>
                  </div>

                  <!-- Completion Bar -->
                  <div>
                    <div style="display:flex; justify-content:space-between; font-size:0.75rem; margin-bottom:4px;">
                      <span>نسبة الإنجاز</span>
                      <strong>${rate}%</strong>
                    </div>
                    <div style="height:6px; background:var(--border); border-radius:3px; overflow:hidden;">
                      <div style="height:100%; width:${rate}%; background:var(--success); border-radius:3px;"></div>
                    </div>
                  </div>

                  ${s.overdue > 0 ? `
                    <div style="background:rgba(239,68,68,0.1); color:var(--danger); font-size:0.75rem; padding:4px 8px; border-radius:6px; display:flex; align-items:center; gap:5px; font-weight:700;">
                      <span>⚠️</span> <span>لديه ${s.overdue} مهام متأخرة عن موعدها</span>
                    </div>
                  ` : ''}
                </div>
              `;
            }).join('')}
          </div>
        </div>
      `;
    }

    // ─────────────────────────────────────────────────────────────────────────────
    // CARD RENDERERS (Claims & Tasks)
    // ─────────────────────────────────────────────────────────────────────────────
    renderClaimCard(c, colorName, isSent = false) {
      const dateStr = c.submitDate ? new Date(c.submitDate).toLocaleDateString('ar-JO') : '-';
      const tender = this.tenders.find(t => t.id === c.tenderId);

      return `
        <div style="background:var(--bg-card); border:1px solid var(--border); border-right:4px solid var(--${colorName}); border-radius:12px; padding:16px; box-shadow:0 2px 10px rgba(0,0,0,0.03); display:flex; flex-direction:column; justify-content:space-between; gap:12px;">
          <div>
            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:8px;">
              <span style="font-weight:800; font-family:monospace; font-size:0.85rem; color:var(--primary);">مطالبة: ${c.id}</span>
              <span style="font-size:0.78rem; color:var(--text-muted);">📅 ${dateStr}</span>
            </div>
            <h4 style="margin:0 0 6px 0; font-size:0.98rem; font-weight:800; color:var(--text);">
              ${tender?.title || c.projectTitle || `مشروع رقم: ${c.tenderId || '-'}`}
            </h4>
            <div style="font-size:0.82rem; color:var(--text-muted); display:flex; flex-direction:column; gap:3px;">
              <div><strong>المقاول:</strong> ${c.claimant || '-'}</div>
              <div><strong>المبلغ المطالب به:</strong> <span style="font-weight:800; color:var(--success);">${parseFloat(c.amount || 0).toLocaleString()} د.أ</span></div>
              <div><strong>الحالة الحالية:</strong> <span style="color:var(--danger); font-weight:700;">${c.status || 'مسودة'}</span></div>
            </div>
          </div>

          <div style="display:flex; justify-content:space-between; align-items:center; border-top:1px solid var(--border); padding-top:10px;">
            <button class="btn btn-primary" onclick="if (typeof viewRecord === 'function') viewRecord('claims', '${c.id}'); else if (typeof unifiedClaimsManager !== 'undefined') unifiedClaimsManager.openAuditModal('${c.id}');" style="font-size:0.82rem; padding:6px 14px;">
              🔍 فتح ملف المطالبة والتدقيق
            </button>
            ${isSent ? `
              <button class="btn btn-outline" onclick="unifiedMyWorkManager.sendClaimReminder('${c.id}')" style="font-size:0.78rem; padding:6px 10px;">
                🔔 تذكير
              </button>
            ` : ''}
          </div>
        </div>
      `;
    }

    renderTaskCard(t, context = 'mine') {
      const prColor = this.getPriorityColor(t.priority);
      const stColor = this.getStatusColor(t.status);
      const attachedFile = t.reportFile || t.reportfile || t.file || t.attachmentPath || '';

      return `
        <div style="background:var(--bg-card); border:1px solid var(--border); border-right:4px solid ${stColor}; border-radius:12px; padding:16px; box-shadow:0 2px 10px rgba(0,0,0,0.03); display:flex; flex-direction:column; justify-content:space-between; gap:12px;">
          <div>
            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:8px;">
              <span style="font-weight:800; font-family:monospace; font-size:0.85rem; color:var(--primary);">${t.id}</span>
              <span class="badge" style="background:${prColor}; color:#fff; font-size:0.72rem; padding:2px 6px; border-radius:4px;">${t.priority || 'عادية'}</span>
            </div>
            <h4 style="margin:0 0 6px 0; font-size:0.98rem; font-weight:800; color:var(--text); line-height:1.4;">
              ${t.title}
            </h4>
            <div style="font-size:0.82rem; color:var(--text-muted); display:flex; flex-direction:column; gap:3px;">
              <div><strong>صاحب الاستدعاء:</strong> ${t.citizenName || '-'} ${t.appealNumber ? `(${t.appealNumber})` : ''}</div>
              <div><strong>المهندس المكلف:</strong> <span style="color:var(--text); font-weight:700;">${t.assignedToName || t.assignedTo || '-'}</span></div>
              <div><strong>تاريخ الاستحقاق:</strong> <span style="color:var(--text);">${t.dueDate || 'غير محدد'}</span></div>
              <div><strong>الحالة:</strong> <span style="color:${stColor}; font-weight:800;">${t.status || 'واردة'}</span></div>
            </div>
          </div>

          <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:6px; border-top:1px solid var(--border); padding-top:10px;">
            <div style="display:flex; gap:6px;">
              <button class="btn btn-outline" onclick="unifiedMyWorkManager.openDetailsModal('${t.id}')" style="font-size:0.82rem; padding:5px 10px;">
                👁️ التفاصيل
              </button>
              ${attachedFile ? `
                <button class="btn btn-outline" onclick="unifiedMyWorkManager.openAttachmentViewer('/uploads/${attachedFile}', 'مرفق المهمة (${t.id})')" style="font-size:0.82rem; padding:5px 8px;" title="معاينة المرفق">
                  📎 المرفق
                </button>
              ` : ''}
            </div>

            <div style="display:flex; gap:6px;">
              ${context === 'mine' && t.status !== 'مكتملة' ? `
                <button class="btn btn-primary" onclick="unifiedMyWorkManager.openReportModal('${t.id}')" style="font-size:0.82rem; padding:5px 12px; background:var(--success); border-color:var(--success); font-weight:700;">
                  📝 إعداد التقرير
                </button>
              ` : ''}
              ${context === 'sent' ? `
                <button class="btn btn-outline" onclick="unifiedMyWorkManager.pingUser('${t.assignedTo}', '${t.assignedToName || t.assignedTo}')" style="font-size:0.78rem; padding:5px 8px;">
                  🔔 تذكير المكلف
                </button>
              ` : ''}
            </div>
          </div>
        </div>
      `;
    }

    // ─────────────────────────────────────────────────────────────────────────────
    // IN-APP DOCUMENT / ATTACHMENT VIEWER ENGINE
    // ─────────────────────────────────────────────────────────────────────────────
    openAttachmentViewer(fileUrl, title = 'معاينة المرفق') {
      if (!fileUrl) return;
      const modal = document.getElementById('umw-viewer-modal');
      const titleEl = document.getElementById('umw-viewer-title');
      const bodyEl = document.getElementById('umw-viewer-body');
      const downloadBtn = document.getElementById('umw-viewer-download-btn');

      if (!modal || !bodyEl) return;

      titleEl.textContent = title;
      downloadBtn.href = fileUrl;

      const ext = fileUrl.split('.').pop().toLowerCase().split('?')[0];
      const isImg = ['jpg', 'jpeg', 'png', 'gif', 'webp', 'svg'].includes(ext);
      const isPdf = ext === 'pdf';

      if (isImg) {
        bodyEl.innerHTML = `
          <div style="display:flex; justify-content:center; align-items:center; width:100%; height:100%;">
            <img src="${fileUrl}" alt="Attachment" style="max-width:100%; max-height:100%; object-fit:contain; border-radius:8px; box-shadow:0 10px 25px rgba(0,0,0,0.5);" />
          </div>
        `;
      } else if (isPdf) {
        bodyEl.innerHTML = `
          <iframe src="${fileUrl}" style="width:100%; height:100%; border:none; border-radius:8px; background:#fff;"></iframe>
        `;
      } else {
        bodyEl.innerHTML = `
          <div style="text-align:center; color:#fff; padding:40px;">
            <div style="font-size:4rem; margin-bottom:14px;">📁</div>
            <h3 style="margin:0 0 10px 0;">نوع الملف: .${ext.toUpperCase()}</h3>
            <p style="color:#94a3b8; font-size:0.9rem; margin-bottom:20px;">لا تتوفر معاينة مباشرة لهذا النوع من الملفات داخل المتصفح.</p>
            <a href="${fileUrl}" download class="btn btn-primary" style="padding:10px 24px; font-weight:800; font-size:1rem;">
              ⬇️ اضغط هنا لتنزيل الملف وفتحه على جهازك
            </a>
          </div>
        `;
      }

      modal.style.display = 'flex';
    }

    closeViewerModal() {
      const modal = document.getElementById('umw-viewer-modal');
      const bodyEl = document.getElementById('umw-viewer-body');
      if (modal) modal.style.display = 'none';
      if (bodyEl) bodyEl.innerHTML = '';
    }

    // ─────────────────────────────────────────────────────────────────────────────
    // TASK MODAL (Add / Edit) with MAP & ATTACHMENT UPLOAD
    // ─────────────────────────────────────────────────────────────────────────────
    openTaskModal(taskId = null) {
      const modal = document.getElementById('umw-task-modal');
      const titleEl = document.getElementById('umw-task-modal-title');
      const form = document.getElementById('umw-task-form');
      if (!modal || !form) return;

      form.reset();
      this.selectedTaskFile = null;
      document.getElementById('task-file-name-display').textContent = 'لم يتم اختيار ملف';
      document.getElementById('btn-remove-task-file').style.display = 'none';
      document.getElementById('task-existing-file-box').style.display = 'none';

      this.populateUserSelects();

      if (taskId) {
        const task = this.tasks.find(t => t.id === taskId);
        if (task) {
          titleEl.innerHTML = `<span>✏️</span> <span>تعديل بيانات المهمة (${task.id})</span>`;
          document.getElementById('task-id').value = task.id;
          document.getElementById('task-title').value = task.title || '';
          document.getElementById('task-appeal-number').value = task.appealNumber || '';
          document.getElementById('task-appeal-date').value = task.appealDate || '';
          document.getElementById('task-citizen-name').value = task.citizenName || '';
          document.getElementById('task-citizen-phone').value = task.citizenPhone || '';
          document.getElementById('task-assigned-to').value = task.assignedTo || '';
          document.getElementById('task-priority').value = task.priority || 'عادية';
          document.getElementById('task-due-date').value = task.dueDate || '';
          document.getElementById('task-status').value = task.status || 'واردة';
          document.getElementById('task-description').value = task.description || '';
          document.getElementById('task-lat').value = task.lat || '';
          document.getElementById('task-lng').value = task.lng || '';

          const existingFile = task.reportFile || task.reportfile || task.file || '';
          if (existingFile) {
            const existingBox = document.getElementById('task-existing-file-box');
            const existingLink = document.getElementById('task-existing-file-link');
            existingBox.style.display = 'block';
            existingLink.href = `/uploads/${existingFile}`;
            existingLink.textContent = existingFile;
            existingLink.onclick = (e) => {
              e.preventDefault();
              this.openAttachmentViewer(`/uploads/${existingFile}`, `مرفق المهمة (${task.id})`);
            };
          }
        }
      } else {
        titleEl.innerHTML = `<span>📋</span> <span>إسناد مهمة كشف ومعاينة فنية جديدة</span>`;
        document.getElementById('task-id').value = '';
        document.getElementById('task-appeal-date').value = new Date().toISOString().split('T')[0];
      }

      modal.style.display = 'flex';
      setTimeout(() => this.initModalMap(), 200);
    }

    closeTaskModal() {
      const modal = document.getElementById('umw-task-modal');
      if (modal) modal.style.display = 'none';
      this.selectedTaskFile = null;
    }

    handleTaskFileSelect(input) {
      if (input.files && input.files[0]) {
        this.selectedTaskFile = input.files[0];
        document.getElementById('task-file-name-display').textContent = `تم اختيار: ${this.selectedTaskFile.name} (${Math.round(this.selectedTaskFile.size / 1024)} KB)`;
        document.getElementById('btn-remove-task-file').style.display = 'inline-block';
      }
    }

    clearTaskFile() {
      this.selectedTaskFile = null;
      const input = document.getElementById('task-file-input');
      if (input) input.value = '';
      document.getElementById('task-file-name-display').textContent = 'لم يتم اختيار ملف';
      document.getElementById('btn-remove-task-file').style.display = 'none';
    }

    initModalMap() {
      const mapEl = document.getElementById('umw-modal-map');
      if (!mapEl || typeof L === 'undefined') return;

      if (this.modalMapInstance) {
        this.modalMapInstance.remove();
        this.modalMapInstance = null;
      }

      const defaultCenter = [32.2985, 35.7050]; // مركز بلدية كفرنجة الجديدة
      const initialLat = parseFloat(document.getElementById('task-lat').value);
      const initialLng = parseFloat(document.getElementById('task-lng').value);
      const center = (initialLat && initialLng) ? [initialLat, initialLng] : defaultCenter;

      if (typeof UnifiedGisEngine !== 'undefined' && typeof UnifiedGisEngine.createMap === 'function') {
        this.modalMapInstance = UnifiedGisEngine.createMap('umw-modal-map', center, 14);
      } else {
        const streetLayer = L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Street_Map/MapServer/tile/{z}/{y}/{x}', { maxZoom: 19, attribution: '&copy; Esri World Street' });
        const satLayer = L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}', { maxZoom: 19, attribution: '&copy; Esri' });
        const osmLayer = L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', { maxZoom: 19, attribution: '&copy; OpenStreetMap' });

        this.modalMapInstance = L.map('umw-modal-map', {
          center: center,
          zoom: 14,
          layers: [streetLayer]
        });

        L.control.layers({
          '🛣️ خريطة الشوارع (Esri Street)': streetLayer,
          '🛰️ صور الأقمار الصناعية (Esri)': satLayer,
          '🌐 خريطة OpenStreetMap': osmLayer
        }, null, { position: 'topright' }).addTo(this.modalMapInstance);
      }

      if (initialLat && initialLng) {
        this.modalMarker = L.marker([initialLat, initialLng]).addTo(this.modalMapInstance);
      }

      this.modalMapInstance.on('click', (e) => {
        const { lat, lng } = e.latlng;
        document.getElementById('task-lat').value = lat.toFixed(6);
        document.getElementById('task-lng').value = lng.toFixed(6);

        if (this.modalMarker) {
          this.modalMarker.setLatLng(e.latlng);
        } else {
          this.modalMarker = L.marker(e.latlng).addTo(this.modalMapInstance);
        }
      });

      setTimeout(() => {
        if (this.modalMapInstance) this.modalMapInstance.invalidateSize();
      }, 300);
    }

    resetModalMapPin() {
      if (this.modalMarker && this.modalMapInstance) {
        this.modalMapInstance.removeLayer(this.modalMarker);
        this.modalMarker = null;
      }
      document.getElementById('task-lat').value = '';
      document.getElementById('task-lng').value = '';
    }

    async saveTask() {
      const id = document.getElementById('task-id').value;
      const title = document.getElementById('task-title').value;
      const appealNumber = document.getElementById('task-appeal-number').value;
      const appealDate = document.getElementById('task-appeal-date').value;
      const citizenName = document.getElementById('task-citizen-name').value;
      const citizenPhone = document.getElementById('task-citizen-phone').value;
      const assignedTo = document.getElementById('task-assigned-to').value;
      const priority = document.getElementById('task-priority').value;
      const dueDate = document.getElementById('task-due-date').value;
      const status = document.getElementById('task-status').value;
      const description = document.getElementById('task-description').value;
      const lat = document.getElementById('task-lat').value;
      const lng = document.getElementById('task-lng').value;

      const formData = new FormData();
      formData.append('title', title);
      formData.append('appealNumber', appealNumber);
      formData.append('appealDate', appealDate);
      formData.append('citizenName', citizenName);
      formData.append('citizenPhone', citizenPhone);
      formData.append('assignedTo', assignedTo);
      formData.append('priority', priority);
      formData.append('dueDate', dueDate);
      formData.append('status', status);
      formData.append('description', description);
      formData.append('lat', lat || 0);
      formData.append('lng', lng || 0);

      if (this.selectedTaskFile) {
        formData.append('file', this.selectedTaskFile);
      }

      try {
        const url = id ? `/api/tasks/${id}` : '/api/tasks';
        const method = id ? 'PUT' : 'POST';

        const res = await fetch(url, {
          method: method,
          headers: {
            'x-user-id': this.currentUser?.id || 'U-001',
            'x-user-role': this.currentUser?.role || 'admin'
          },
          body: formData
        });

        const data = await res.json();
        if (!res.ok) throw new Error(data.error || 'فشل حفظ المهمة');

        this.showToast(id ? '✅ تم تحديث بيانات المهمة بنجاح' : '✅ تم إسناد المهمة بنجاح');
        this.closeTaskModal();
        await this.loadAllData();
      } catch (err) {
        console.error('Save task error:', err);
        alert('حدث خطأ أثناء حفظ المهمة: ' + err.message);
      }
    }

    async deleteTask(id) {
      if (!confirm(`هل أنت متأكد من حذف المهمة (${id}) نهائياً؟`)) return;
      try {
        await apiFetch(`/tasks/${id}`, { method: 'DELETE' });
        this.showToast('🗑️ تم حذف المهمة بنجاح');
        await this.loadAllData();
      } catch (err) {
        alert('حدث خطأ أثناء الحذف: ' + err.message);
      }
    }

    // ─────────────────────────────────────────────────────────────────────────────
    // REPORT MODAL (Technical Inspection Report)
    // ─────────────────────────────────────────────────────────────────────────────
    openReportModal(taskId) {
      const task = this.tasks.find(t => t.id === taskId);
      if (!task) return;

      const modal = document.getElementById('umw-report-modal');
      const form = document.getElementById('umw-report-form');
      const summaryEl = document.getElementById('report-task-summary');

      if (!modal || !form) return;

      form.reset();
      this.selectedReportFile = null;
      document.getElementById('report-file-name-display').textContent = 'لم يتم اختيار ملف';
      document.getElementById('btn-remove-report-file').style.display = 'none';

      document.getElementById('report-task-id').value = task.id;
      document.getElementById('report-text').value = task.reportText || '';

      summaryEl.innerHTML = `
        <div style="font-weight:800; color:var(--primary); margin-bottom:4px;">${task.id}: ${task.title}</div>
        <div style="color:var(--text-muted); font-size:0.8rem;">
          المستدعي: <strong>${task.citizenName || '-'}</strong> | رقم الاستدعاء: ${task.appealNumber || '-'} | تاريخ الاستحقاق: ${task.dueDate || '-'}
        </div>
      `;

      modal.style.display = 'flex';
    }

    closeReportModal() {
      const modal = document.getElementById('umw-report-modal');
      if (modal) modal.style.display = 'none';
      this.selectedReportFile = null;
    }

    handleReportFileSelect(input) {
      if (input.files && input.files[0]) {
        this.selectedReportFile = input.files[0];
        document.getElementById('report-file-name-display').textContent = `تم اختيار: ${this.selectedReportFile.name} (${Math.round(this.selectedReportFile.size / 1024)} KB)`;
        document.getElementById('btn-remove-report-file').style.display = 'inline-block';
      }
    }

    clearReportFile() {
      this.selectedReportFile = null;
      const input = document.getElementById('report-file-input');
      if (input) input.value = '';
      document.getElementById('report-file-name-display').textContent = 'لم يتم اختيار ملف';
      document.getElementById('btn-remove-report-file').style.display = 'none';
    }

    applyReportTemplate(templateKey) {
      const txt = document.getElementById('report-text');
      if (!txt) return;

      const templates = {
        roads: `تقرير كشف ومعاينة طريق واسفلت:
─────────────────────────────────────────────
1. الموقع والملاحظات الحسيّة:
   - حالة الشارع الحالي: وجود تخسفات وهبوط اسفلتي يحتاج لصيانة عاجلة.
   - قياسات المساحة المقدرة: ................. م²
2. التوصيات والحلول الهندسية:
   - قص طبقة الاسفلت المهترئة وتوريد خلطة اسفلتية ساخنة ودحلها حسب المواصفات.
   - كلفة تقديرية أولية: ................. دينار أردني.
3. المعتمد: يرجى التكرم بالموافقة على الإيعاز لورشة التعبيد بإجراء اللازم.`,

        building: `تقرير كشف ترخيص، أبنية وعوائق تنظيمية:
─────────────────────────────────────────────
1. واقع الحال التنظيمي:
   - مطابقة البناء/الجدار مع المخطط التنظيمي المعتمد.
   - سعة الشارع المقررة: ................. متر.
2. التوصية الفنية:
   - لا مانع من منح التصريح / الترخيص شريطة الالتزام بالارتدادات القانونية وإزالة العوائق.`,

        water: `تقرير كشف شبكات تصريف مياه الأمطار والعبارات:
─────────────────────────────────────────────
1. حالة مجرى المياه والعبارة:
   - سلامة الجريان وجاهزية المناهل وخطوط التصريف.
2. التوصيات:
   - تنظيف الطمي وتأهيل مدخل ومخرج العبارة الصندوقية لحماية السلامة العامة.`,

        lighting: `تقرير فحص وصيانة شبكة إنارة الشوارع:
─────────────────────────────────────────────
1. عدد الوحدات المتعطلة: ................. وحدة إنارة LED.
2. المواد اللازمة: لمبات ليد، فوتوسيل، وكوابل معزولة.
3. التوصية: الإيعاز لفرقة طوارئ الكهرباء لإجراء الصيانة الفورية.`,

        general: `تقرير كشف ومعاينة ميدانية:
─────────────────────────────────────────────
- بناءً على استدعاء المواطن المشار إليه أعلاه، تم إجراء الكشف الميداني وتبين ما يلي:
.........................................................................................
- التوصية الهندسية:
.........................................................................................
يعتمد للتوجيه والمتابعة،`
      };

      if (templates[templateKey]) {
        txt.value = templates[templateKey];
      }
    }

    async submitReport() {
      const taskId = document.getElementById('report-task-id').value;
      const reportTemplate = document.getElementById('report-template-select').value;
      const reportText = document.getElementById('report-text').value;

      if (!reportText.trim()) {
        alert('يرجى كتابة نص وتوصيات التقرير الفني');
        return;
      }

      const formData = new FormData();
      formData.append('reportTemplate', reportTemplate);
      formData.append('reportText', reportText);

      if (this.selectedReportFile) {
        formData.append('reportFile', this.selectedReportFile);
      }

      try {
        const res = await fetch(`/api/tasks/${taskId}/report`, {
          method: 'POST',
          headers: {
            'x-user-id': this.currentUser?.id || 'U-001',
            'x-user-role': this.currentUser?.role || 'admin'
          },
          body: formData
        });

        const data = await res.json();
        if (!res.ok) throw new Error(data.error || 'فشل اعتماد التقرير');

        this.showToast('✅ تم حفظ واعتماد التقرير الفني وإغلاق المهمة بنجاح');
        this.closeReportModal();
        await this.loadAllData();
      } catch (err) {
        console.error('Submit report error:', err);
        alert('حدث خطأ أثناء رفع التقرير: ' + err.message);
      }
    }

    // ─────────────────────────────────────────────────────────────────────────────
    // TASK DETAILS MODAL & ACTIVE ATTACHMENTS / AUDIT TRAIL / ROLES
    // ─────────────────────────────────────────────────────────────────────────────
    openDetailsModal(taskId) {
      const task = this.tasks.find(t => t.id === taskId);
      if (!task) return;

      this.currentDetailTaskId = taskId;
      this.selectedCommentFile = null;
      const modal = document.getElementById('umw-details-modal');
      const bodyEl = document.getElementById('umw-details-body');
      const titleEl = document.getElementById('umw-details-title');

      if (!modal || !bodyEl) return;

      titleEl.innerHTML = `<span>📋</span> <span>تفاصيل المهمة والكشف الفني (${task.id})</span>`;

      const prColor = this.getPriorityColor(task.priority);
      const stColor = this.getStatusColor(task.status);
      const attachedFile = task.reportFile || task.reportfile || task.file || '';

      const isManager = this.isManagerOrAdmin();
      const myId = this.currentUser?.id;
      const myRole = this.currentUser?.role;
      const myName = this.currentUser?.fullName;
      const isAssigned = (task.assignedTo === myId || task.assignedTo === myRole || task.assignedTo === myName || (task.assignedToName && task.assignedToName === myName));
      const canSubmitReport = isManager || isAssigned;
      const isCompleted = task.status === 'مكتملة';

      let commentsArr = [];
      if (task.comments) {
        try {
          commentsArr = typeof task.comments === 'string' ? JSON.parse(task.comments) : task.comments;
        } catch (e) {}
      }

      bodyEl.innerHTML = `
        <div style="display:flex; flex-direction:column; gap:18px;">
          
          <!-- Role Actions Toolbar Header -->
          <div style="background:var(--bg-card); border:1px solid var(--border); border-radius:12px; padding:12px 16px; display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:10px;">
            <div style="display:flex; align-items:center; gap:8px; flex-wrap:wrap;">
              <span style="font-size:0.85rem; font-weight:700; color:var(--text-muted);">حالة المعاملة:</span>
              <select onchange="unifiedMyWorkManager.changeTaskStatus('${task.id}', this.value)" style="padding:6px 12px; border-radius:8px; border:1px solid var(--border); background:var(--bg); color:var(--text); font-weight:700; font-size:0.85rem; cursor:pointer;">
                <option value="واردة" ${task.status === 'واردة' ? 'selected' : ''}>📥 واردة / بانتظار البدء</option>
                <option value="قيد الكشف" ${task.status === 'قيد الكشف' ? 'selected' : ''}>🔍 قيد الكشف الفني</option>
                <option value="معلقة" ${task.status === 'معلقة' ? 'selected' : ''}>⏸️ معلقة / بانتظار استكمال</option>
                <option value="مكتملة" ${task.status === 'مكتملة' ? 'selected' : ''}>✅ مكتملة / تم إعداد التقرير</option>
                <option value="ملغاة" ${task.status === 'ملغاة' ? 'selected' : ''}>❌ ملغاة</option>
              </select>
            </div>

            <div style="display:flex; gap:8px; flex-wrap:wrap; align-items:center;">
              ${canSubmitReport ? `
                <button class="btn btn-primary" onclick="unifiedMyWorkManager.closeDetailsModal(); unifiedMyWorkManager.openReportModal('${task.id}')" style="font-weight:700; font-size:0.84rem; display:flex; align-items:center; gap:5px; background:linear-gradient(135deg, #10b981 0%, #059669 100%); border:none;">
                  <span>📝</span> <span>${isCompleted ? 'تعديل التقرير الفني' : 'إعداد ورفع التقرير الفني'}</span>
                </button>
              ` : ''}

              ${isManager ? `
                <button class="btn btn-outline" onclick="unifiedMyWorkManager.closeDetailsModal(); unifiedMyWorkManager.openTaskModal('${task.id}')" title="تعديل بيانات التكليف" style="font-size:0.84rem; font-weight:700;">
                  ✏️ تعديل التكليف
                </button>
              ` : ''}

              <button class="btn btn-outline" onclick="unifiedMyWorkManager.printTaskCertificate()" title="طباعة التقرير الفني المعتمد" style="font-size:0.84rem; font-weight:700;">
                🖨️ طباعة التقرير الفني
              </button>

              ${isManager ? `
                <button class="btn btn-outline" onclick="unifiedMyWorkManager.deleteTask('${task.id}')" title="حذف المهمة" style="color:var(--danger); border-color:rgba(239,68,68,0.3); font-size:0.84rem; font-weight:700;">
                  🗑️ حذف
                </button>
              ` : ''}
            </div>
          </div>

          <!-- Main Task Information Card -->
          <div style="background:var(--bg-card); border-radius:12px; padding:18px; border:1px solid var(--border); box-shadow:0 2px 8px rgba(0,0,0,0.03);">
            <div style="display:flex; justify-content:space-between; align-items:flex-start; margin-bottom:12px;">
              <div>
                <h3 style="margin:0; font-size:1.15rem; font-weight:800; color:var(--text);">${task.title}</h3>
                <p style="color:var(--text-muted); font-size:0.88rem; margin:6px 0 0 0; line-height:1.5;">${task.description || 'لا يوجد وصف تفصيلي مسجل'}</p>
              </div>
              <div style="display:flex; gap:6px; flex-shrink:0;">
                <span class="badge" style="background:${prColor}; color:#fff; font-size:0.75rem; padding:4px 10px; border-radius:6px; font-weight:700;">${task.priority || 'عادية'}</span>
                <span class="badge" style="background:${stColor}; color:#fff; font-size:0.75rem; padding:4px 10px; border-radius:6px; font-weight:700;">${task.status}</span>
              </div>
            </div>

            <div style="display:grid; grid-template-columns:repeat(auto-fit, minmax(210px, 1fr)); gap:12px; font-size:0.85rem; border-top:1px solid var(--border); padding-top:14px; background:var(--bg); margin:0 -18px -18px -18px; padding:14px 18px; border-radius:0 0 12px 12px;">
              <div><span style="color:var(--text-muted);">رقم الاستدعاء:</span> <strong style="color:var(--text);">${task.appealNumber || '-'}</strong></div>
              <div><span style="color:var(--text-muted);">تاريخ الاستدعاء:</span> <strong style="color:var(--text);">${task.appealDate || '-'}</strong></div>
              <div><span style="color:var(--text-muted);">صاحب الاستدعاء:</span> <strong style="color:var(--text);">${task.citizenName || '-'}</strong></div>
              <div><span style="color:var(--text-muted);">رقم هاتف المواطن:</span> <strong style="color:var(--text);">${task.citizenPhone || '-'}</strong></div>
              <div><span style="color:var(--text-muted);">المهندس المكلف:</span> <strong style="color:var(--primary);">${task.assignedToName || task.assignedTo || '-'}</strong></div>
              <div><span style="color:var(--text-muted);">تاريخ الاستحقاق:</span> <strong style="color:var(--text);">${task.dueDate || '-'}</strong></div>
            </div>
          </div>

          <!-- Official Document & Attachment Zone -->
          <div style="background:var(--bg-card); border:1px solid var(--border); border-radius:12px; padding:16px;">
            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:12px;">
              <h4 style="margin:0; font-size:0.95rem; font-weight:800; color:var(--text); display:flex; align-items:center; gap:6px;">
                <span>📎</span> <span>المرفقات والوثائق الهندسية المعتمدة</span>
              </h4>
              <div>
                <input type="file" id="direct-task-file-input" style="display:none;" onchange="unifiedMyWorkManager.uploadDirectAttachment('${task.id}', this.files[0])" />
                <button class="btn btn-outline" onclick="document.getElementById('direct-task-file-input').click()" style="font-size:0.8rem; font-weight:700; display:flex; align-items:center; gap:5px; padding:6px 12px;">
                  <span>📤</span> <span>${attachedFile ? 'استبدال / رفع ملف إضافي' : '+ إرفاق ملف / استدعاء / مخطط'}</span>
                </button>
              </div>
            </div>

            ${attachedFile ? `
              <div style="background:rgba(2,132,199,0.06); border:1px solid rgba(2,132,199,0.25); border-radius:10px; padding:12px 16px; display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:10px;">
                <div style="display:flex; align-items:center; gap:12px;">
                  <div style="font-size:1.8rem;">📄</div>
                  <div>
                    <div style="font-weight:800; font-size:0.9rem; color:var(--text);">${attachedFile}</div>
                    <div style="font-size:0.75rem; color:var(--text-muted);">وثيقة رسمية مرفقة ومحفوظة في الخادم</div>
                  </div>
                </div>
                <div style="display:flex; gap:8px;">
                  <button class="btn btn-primary" onclick="unifiedMyWorkManager.openAttachmentViewer('/uploads/${attachedFile}', 'مرفق المهمة (${task.id})')" style="font-size:0.82rem; padding:7px 14px; font-weight:700; display:flex; align-items:center; gap:5px;">
                    <span>👁️</span> <span>معاينة فورية</span>
                  </button>
                  <a class="btn btn-outline" href="/uploads/${attachedFile}" download style="font-size:0.82rem; padding:7px 12px; font-weight:700; text-decoration:none; display:flex; align-items:center; gap:5px;">
                    <span>📥</span> <span>تحميل</span>
                  </a>
                </div>
              </div>
            ` : `
              <div style="border:2px dashed var(--border); border-radius:10px; padding:20px; text-align:center; color:var(--text-muted); font-size:0.85rem; background:var(--bg);">
                <div style="font-size:1.6rem; margin-bottom:6px;">📭</div>
                <div>لا يوجد ملف أو وثيقة مرفقة حالياً لهذه المهمة.</div>
                <div style="font-size:0.76rem; margin-top:4px;">يمكنك النقر على الزر بالأعلى لإرفاق استدعاء المواطن أو صور الكشف الميداني.</div>
              </div>
            `}
          </div>

          <!-- Technical Inspection Report Display (If Submitted) -->
          ${task.reportText ? `
            <div style="background:var(--bg-card); border:1px solid var(--success); border-right:5px solid var(--success); border-radius:12px; padding:16px; box-shadow:0 2px 8px rgba(0,0,0,0.03);">
              <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:10px; border-bottom:1px solid var(--border); padding-bottom:8px;">
                <h4 style="margin:0; font-size:0.98rem; font-weight:800; color:var(--success); display:flex; align-items:center; gap:6px;">
                  <span>📝</span> <span>التقرير والتوصيات الهندسية الميدانية المعتمدة</span>
                </h4>
                <span style="font-size:0.78rem; color:var(--text-muted); font-weight:600;">تاريخ الكشف: ${task.reportDate || '-'}</span>
              </div>
              <div style="white-space:pre-wrap; font-size:0.88rem; color:var(--text); line-height:1.7; background:var(--bg); padding:14px; border-radius:8px; border:1px solid var(--border); font-family:inherit;">
                ${task.reportText}
              </div>
            </div>
          ` : ''}

          <!-- Comments, Timeline & Technical Notes -->
          <div style="background:var(--bg-card); border:1px solid var(--border); border-radius:12px; padding:16px;">
            <h4 style="margin:0 0 12px 0; font-size:0.95rem; font-weight:800; color:var(--text); display:flex; align-items:center; gap:6px;">
              <span>💬</span> <span>سجل الملاحظات والتواصل الفني والرقابي</span>
            </h4>
            
            <div style="display:flex; flex-direction:column; gap:10px; margin-bottom:14px; max-height:220px; overflow-y:auto; padding-left:4px;">
              ${commentsArr.length ? commentsArr.map(c => `
                <div style="background:var(--bg); border-radius:8px; padding:10px 14px; border:1px solid var(--border); font-size:0.85rem;">
                  <div style="display:flex; justify-content:space-between; margin-bottom:4px; font-size:0.75rem; color:var(--text-muted);">
                    <strong style="color:var(--accent);">${c.authorName || 'مستخدم'}</strong>
                    <span>${c.date ? new Date(c.date).toLocaleString('ar-JO') : ''}</span>
                  </div>
                  <div style="color:var(--text); line-height:1.4;">${c.text}</div>
                  ${c.attachment ? `
                    <div style="margin-top:8px;">
                      <a href="#" onclick="unifiedMyWorkManager.openAttachmentViewer('/uploads/${c.attachment}', 'مرفق التعليق'); return false;" style="display:inline-flex; align-items:center; gap:5px; font-size:0.76rem; color:var(--primary); font-weight:700; background:rgba(59,130,246,0.1); padding:3px 10px; border-radius:12px; text-decoration:none;">
                        <span>📎</span> <span>معاينة المرفق: ${c.attachment}</span>
                      </a>
                    </div>
                  ` : ''}
                </div>
              `).join('') : '<div style="color:var(--text-muted); font-size:0.84rem; text-align:center; padding:15px;">لا توجد ملاحظات مسجلة حتى الآن. كن أول من يضيف توجيهاً فنياً.</div>'}
            </div>

            <!-- Active File Selection Pill for Comment -->
            <div id="comment-file-preview-pill" style="display:none; margin-bottom:10px; align-items:center; justify-content:space-between; background:rgba(2,132,199,0.12); border:1px solid rgba(2,132,199,0.3); border-radius:8px; padding:6px 12px; font-size:0.82rem; color:var(--primary); font-weight:700;">
              <div style="display:flex; align-items:center; gap:6px;">
                <span>📎</span>
                <span id="comment-file-name-text">تم اختيار ملف</span>
              </div>
              <button onclick="unifiedMyWorkManager.clearCommentFile()" style="background:none; border:none; color:var(--danger); cursor:pointer; font-weight:bold; font-size:0.9rem;" title="إلغاء المرفق">✕</button>
            </div>

            <!-- Add Comment Form -->
            <div style="display:flex; gap:8px; align-items:center;">
              <input type="text" id="new-task-comment-text" placeholder="اكتب ملاحظة أو توجيه فني للمهندس المكلف..." style="flex:1; padding:9px 12px; border:1px solid var(--border); border-radius:8px; background:var(--bg); color:var(--text); font-size:0.85rem;" onkeypress="if(event.key==='Enter') unifiedMyWorkManager.addComment('${task.id}');" />
              <input type="file" id="comment-file-input" style="display:none;" onchange="unifiedMyWorkManager.handleCommentFileSelect(this)" />
              <button class="btn btn-outline" id="btn-comment-attach-icon" onclick="document.getElementById('comment-file-input').click()" title="إرفاق ملف أو وثيقة مع الملاحظة" style="padding:8px 12px; display:flex; align-items:center; gap:4px; font-weight:700;">
                <span>📎</span>
              </button>
              <button class="btn btn-primary" onclick="unifiedMyWorkManager.addComment('${task.id}')" style="font-weight:700; padding:8px 18px; background:linear-gradient(135deg, var(--primary) 0%, var(--primary-dark) 100%);">
                إرسال
              </button>
            </div>
          </div>

        </div>
      `;

      modal.style.display = 'flex';
    }

    closeDetailsModal() {
      const modal = document.getElementById('umw-details-modal');
      if (modal) modal.style.display = 'none';
      this.currentDetailTaskId = null;
      this.selectedCommentFile = null;
    }

    handleCommentFileSelect(input) {
      if (input.files && input.files[0]) {
        this.selectedCommentFile = input.files[0];
        const pill = document.getElementById('comment-file-preview-pill');
        const text = document.getElementById('comment-file-name-text');
        const attachBtn = document.getElementById('btn-comment-attach-icon');
        if (pill && text) {
          text.textContent = `تم إرفاق: ${this.selectedCommentFile.name} (${Math.round(this.selectedCommentFile.size / 1024)} KB)`;
          pill.style.display = 'flex';
        }
        if (attachBtn) {
          attachBtn.style.borderColor = 'var(--primary)';
          attachBtn.style.color = 'var(--primary)';
        }
      }
    }

    clearCommentFile() {
      this.selectedCommentFile = null;
      const input = document.getElementById('comment-file-input');
      if (input) input.value = '';
      const pill = document.getElementById('comment-file-preview-pill');
      const attachBtn = document.getElementById('btn-comment-attach-icon');
      if (pill) pill.style.display = 'none';
      if (attachBtn) {
        attachBtn.style.borderColor = 'var(--border)';
        attachBtn.style.color = 'var(--text)';
      }
    }

    async uploadDirectAttachment(taskId, file) {
      if (!file) return;
      const formData = new FormData();
      formData.append('file', file);

      try {
        const res = await fetch(`/api/tasks/${taskId}/attachment`, {
          method: 'POST',
          headers: {
            'x-user-id': this.currentUser?.id || 'U-001',
            'x-user-role': this.currentUser?.role || 'admin'
          },
          body: formData
        });

        const data = await res.json();
        if (!res.ok) throw new Error(data.error || 'فشل إرفاق الملف');

        this.showToast('✅ تم رفع وإرفاق الملف بنجاح');
        await this.loadAllData();
        this.openDetailsModal(taskId);
      } catch (err) {
        alert('حدث خطأ أثناء رفع الملف: ' + err.message);
      }
    }

    async changeTaskStatus(taskId, newStatus) {
      try {
        const res = await fetch(`/api/tasks/${taskId}/status`, {
          method: 'PATCH',
          headers: {
            'Content-Type': 'application/json',
            'x-user-id': this.currentUser?.id || 'U-001',
            'x-user-role': this.currentUser?.role || 'admin'
          },
          body: JSON.stringify({ status: newStatus })
        });

        const data = await res.json();
        if (!res.ok) throw new Error(data.error || 'فشل تحديث الحالة');

        this.showToast(`🔄 تم تحديث حالة المهمة إلى: ${newStatus}`);
        await this.loadAllData();
        this.openDetailsModal(taskId);
      } catch (err) {
        alert('حدث خطأ أثناء تغيير الحالة: ' + err.message);
      }
    }

    async addComment(taskId) {
      const input = document.getElementById('new-task-comment-text');
      if (!input || (!input.value.trim() && !this.selectedCommentFile)) return;

      const text = input.value.trim() || 'مرفق مستند';
      const formData = new FormData();
      formData.append('text', text);
      if (this.selectedCommentFile) {
        formData.append('file', this.selectedCommentFile);
      }

      try {
        const res = await fetch(`/api/tasks/${taskId}/comments`, {
          method: 'POST',
          headers: {
            'x-user-id': this.currentUser?.id || 'U-001',
            'x-user-role': this.currentUser?.role || 'admin'
          },
          body: formData
        });

        if (!res.ok) throw new Error('فشل إضافة الملاحظة');

        input.value = '';
        this.clearCommentFile();
        this.showToast('💬 تم تسجيل الملاحظة بنجاح');
        await this.loadAllData();
        this.openDetailsModal(taskId);
      } catch (err) {
        alert(err.message);
      }
    }

    // ─────────────────────────────────────────────────────────────────────────────
    // UNIFIED PRINT ENGINE INTEGRATION (Official Technical Inspection Report)
    // ─────────────────────────────────────────────────────────────────────────────
    printTaskCertificate() {
      if (!this.currentDetailTaskId) return;
      const task = this.tasks.find(t => t.id === this.currentDetailTaskId);
      if (!task) return;

      const rawLat = parseFloat(task.lat);
      const rawLng = parseFloat(task.lng);
      const hasCoords = !isNaN(rawLat) && !isNaN(rawLng) && rawLat !== 0 && rawLng !== 0;
      const taskLat = hasCoords ? rawLat : 32.2985;
      const taskLng = hasCoords ? rawLng : 35.7050;

      if (typeof printStandardDocument === 'function') {
        printStandardDocument({
          title: 'تقرير فني',
          subtitle: `تقرير كشف ومعاينة فنية للمهمة: ${task.id} - ${task.title}`,
          refNumber: task.appealNumber || task.id,
          date: task.reportDate || new Date().toLocaleDateString('ar-JO'),
          fields: [
            { label: 'رقم المهمة', value: task.id },
            { label: 'عنوان الكشف', value: task.title },
            { label: 'رقم وتاريخ الاستدعاء', value: `${task.appealNumber || '-'} بتاريخ ${task.appealDate || '-'}` },
            { label: 'المواطن المستدعي', value: task.citizenName || '-' },
            { label: 'رقم الهاتف', value: task.citizenPhone || '-' },
            { label: 'المهندس المكلف بالكشف', value: task.assignedToName || task.assignedTo || '-' },
            { label: 'الأولوية والحالة', value: `${task.priority} - ${task.status}` },
            { label: 'تاريخ الاستحقاق', value: task.dueDate || '-' }
          ],
          summaryHtml: `
            <!-- مخطط الإسناد الجغرافي وخريطة الموقع التفاعلية للكشف (أعلى التقرير) -->
            <div style="background:#f8fafc; border:1.5px solid #cbd5e1; border-radius:8px; padding:10px 14px; margin-top:14px; margin-bottom:14px; page-break-inside:avoid; break-inside:avoid;">
              <div style="display:flex; justify-content:space-between; align-items:center; border-bottom:1px solid #cbd5e1; padding-bottom:6px; margin-bottom:8px;">
                <div style="font-weight:800; font-size:0.88rem; color:#1e3a8a; display:flex; align-items:center; gap:6px;">
                  🗺️ مخطط الموقع والإسناد الجغرافي للمهمة والكشف الفني (GIS Location Map)
                </div>
                <div style="font-size:0.78rem; color:#475569;">
                  <span><b>الإحداثيات:</b> خط العرض: ${taskLat.toFixed(6)} | خط الطول: ${taskLng.toFixed(6)}</span>
                  ${!hasCoords ? '<span style="color:#d97706; margin-right:4px;">(مركز بلدية كفرنجة)</span>' : ''}
                </div>
              </div>
              <div id="print-task-gis-map" style="width:100% !important; min-width:100%; height:230px; border-radius:6px; border:1px solid #cbd5e1; background:#e2e8f0; overflow:hidden; position:relative;"></div>
            </div>

            <!-- نتائج الكشف الفني والتوصيات المعتمدة -->
            <div style="border:1.5px solid #1e3a8a; border-radius:8px; padding:14px; background:#f8fafc; page-break-inside:avoid;">
              <h4 style="margin:0 0 8px 0; color:#1e3a8a; font-weight:800; font-size:0.95rem; display:flex; align-items:center; gap:6px;">
                <span>📝</span> <span>نتائج الكشف الفني والتوصيات الهندسية المعتمدة:</span>
              </h4>
              <div style="white-space:pre-wrap; line-height:1.7; font-size:0.9rem; color:#0f172a; background:#ffffff; padding:12px; border-radius:6px; border:1px solid #cbd5e1; font-family:inherit;">
                ${task.reportText || 'لا يوجد نص تقرير فني مسجل حتى تاريخه.'}
              </div>
            </div>

            <script>
              (function() {
                function renderTaskPrintMap() {
                  var el = document.getElementById('print-task-gis-map');
                  if (!el || typeof L === 'undefined') return;
                  try {
                    var lat = ${taskLat};
                    var lng = ${taskLng};

                    var streetLayer = L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                      maxZoom: 19,
                      attribution: '&copy; OpenStreetMap'
                    });

                    var satLayer = L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}', {
                      maxZoom: 19,
                      attribution: '&copy; Esri Satellite'
                    });

                    var esriStreetLayer = L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Street_Map/MapServer/tile/{z}/{y}/{x}', {
                      maxZoom: 19,
                      attribution: '&copy; Esri World Street'
                    });

                    var topoLayer = L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Topo_Map/MapServer/tile/{z}/{y}/{x}', {
                      maxZoom: 19,
                      attribution: '&copy; Esri Topo'
                    });

                    var map = L.map('print-task-gis-map', {
                      zoomControl: false,
                      attributionControl: false,
                      layers: [streetLayer]
                    }).setView([lat, lng], 16);

                    L.control.layers({
                      '🌐 خريطة الشوارع العامة (OSM)': streetLayer,
                      '🛰️ صور الأقمار الصناعية (Esri Satellite)': satLayer,
                      '🛣️ خريطة الملاحة والشوارع (Esri Street)': esriStreetLayer,
                      '🏔️ الخريطة الطبوغرافية (Esri Topo)': topoLayer
                    }, null, { position: 'topright' }).addTo(map);

                    var marker = L.marker([lat, lng]).addTo(map);
                    marker.bindPopup('<b>${(task.title || '').replace(/'/g, "\\'")}</b><br>المهمة: ${task.id}').openPopup();

                    setTimeout(function() { map.invalidateSize(); }, 50);
                    setTimeout(function() { map.invalidateSize(); }, 200);
                    setTimeout(function() { map.invalidateSize(); }, 450);
                  } catch(e) { console.error('Print map error:', e); }
                }
                if (document.readyState === 'complete') renderTaskPrintMap();
                else window.addEventListener('load', renderTaskPrintMap);
                setTimeout(renderTaskPrintMap, 80);
              })();
            </script>
          `,
          signatures: true,
          attachments: task.reportFile ? `مرفق تقرير فني وصور المعاينة (${task.reportFile})` : 'لا يوجد'
        });
      } else {
        window.print();
      }
    }

    // ─────────────────────────────────────────────────────────────────────────────
    // NOTIFICATIONS & PINGS
    // ─────────────────────────────────────────────────────────────────────────────
    async pingUser(userId, userName) {
      if (!userId) return;
      try {
        await apiFetch('/notifications', {
          method: 'POST',
          body: JSON.stringify({
            userId,
            title: '🔔 تذكير بمتابعة إجراء / مهمة عمل',
            message: `تذكير موجه من ${this.currentUser?.fullName || 'الإدارة'} بمتابعة المهام المسندة وإنجازها`,
            link: 'my-work',
            type: 'tasks'
          }),
          silent: true
        });
        this.showToast(`🔔 تم إرسال إشعار تذكير فوري إلى (${userName})`);
      } catch (e) {
        this.showToast(`🔔 تم إرسال التذكير بنجاح`);
      }
    }

    async sendClaimReminder(claimId) {
      this.showToast(`🔔 تم إرسال إشعار تذكير لمتابعة المطالبة (${claimId})`);
    }

    // ─────────────────────────────────────────────────────────────────────────────
    // EXPORT TO EXCEL
    // ─────────────────────────────────────────────────────────────────────────────
    exportExcel() {
      if (!this.tasks.length) {
        alert('لا توجد بيانات للتصدير');
        return;
      }

      const headers = ['رقم المهمة', 'العنوان', 'رقم الاستدعاء', 'تاريخ الاستدعاء', 'المواطن', 'الهاتف', 'المهندس المكلف', 'الأولوية', 'الحالة', 'تاريخ الاستحقاق', 'التقرير الفني'];
      const rows = this.tasks.map(t => [
        t.id,
        t.title,
        t.appealNumber || '',
        t.appealDate || '',
        t.citizenName || '',
        t.citizenPhone || '',
        t.assignedToName || t.assignedTo || '',
        t.priority || 'عادية',
        t.status || 'واردة',
        t.dueDate || '',
        (t.reportText || '').replace(/\n/g, ' ')
      ]);

      let csv = '\uFEFF' + headers.join(',') + '\n';
      rows.forEach(r => {
        csv += r.map(f => `"${String(f).replace(/"/g, '""')}"`).join(',') + '\n';
      });

      const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
      const link = document.createElement('a');
      link.href = URL.createObjectURL(blob);
      link.download = `سجل_الكشوفات_والمهام_بلدية_كفرنجة_${new Date().toISOString().split('T')[0]}.csv`;
      link.click();
    }

    // ─────────────────────────────────────────────────────────────────────────────
    // UTILITIES
    // ─────────────────────────────────────────────────────────────────────────────
    onSearchChange(val) {
      this.searchTerm = val;
      this.renderActiveTab();
    }

    onStatusFilterChange(val) {
      this.statusFilter = val;
      this.renderActiveTab();
    }

    onPriorityFilterChange(val) {
      this.priorityFilter = val;
      this.renderActiveTab();
    }

    onAssigneeFilterChange(val) {
      this.assigneeFilter = val;
      this.renderActiveTab();
    }

    resetFilters() {
      this.searchTerm = '';
      this.statusFilter = '';
      this.priorityFilter = '';
      this.assigneeFilter = '';
      this.renderActiveTab();
    }

    setViewMode(mode) {
      this.viewMode = mode;
      this.renderActiveTab();
    }

    getPriorityColor(priority) {
      if (priority === 'حرجة' || priority === 'طارئة') return '#ef4444';
      if (priority === 'عالية') return '#f97316';
      if (priority === 'متوسطة') return '#f59e0b';
      return 'var(--primary)';
    }

    getStatusColor(status) {
      if (status === 'مكتملة') return 'var(--success)';
      if (status === 'قيد الكشف') return '#f59e0b';
      if (status === 'ملغاة') return 'var(--danger)';
      return 'var(--primary)';
    }

    async deleteTask(taskId) {
      if (!confirm(`هل أنت متأكد من حذف المهمة (${taskId}) نهائياً؟`)) return;
      try {
        const res = await fetch(`/api/tasks/${taskId}`, {
          method: 'DELETE',
          headers: {
            'x-user-id': this.currentUser?.id || 'U-001',
            'x-user-role': this.currentUser?.role || 'admin'
          }
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.error || 'فشل حذف المهمة');
        this.showToast('🗑️ تم حذف المهمة بنجاح');
        this.closeDetailsModal();
        await this.loadAllData();
      } catch (e) {
        alert('خطأ أثناء الحذف: ' + e.message);
      }
    }

    printRegistry() {
      if (typeof printStandardDocument === 'function') {
        const rowsHtml = this.tasks.map((t, idx) => `
          <tr>
            <td style="padding:8px; border:1px solid #cbd5e1; text-align:center;">${idx + 1}</td>
            <td style="padding:8px; border:1px solid #cbd5e1; font-weight:bold;">${t.id}</td>
            <td style="padding:8px; border:1px solid #cbd5e1;">${t.title}</td>
            <td style="padding:8px; border:1px solid #cbd5e1;">${t.appealNumber || '-'} (${t.citizenName || '-'})</td>
            <td style="padding:8px; border:1px solid #cbd5e1;">${t.assignedToName || t.assignedTo || '-'}</td>
            <td style="padding:8px; border:1px solid #cbd5e1; text-align:center;">${t.priority || 'عادية'}</td>
            <td style="padding:8px; border:1px solid #cbd5e1; text-align:center;">${t.status || 'واردة'}</td>
            <td style="padding:8px; border:1px solid #cbd5e1; text-align:center;">${t.dueDate || '-'}</td>
          </tr>
        `).join('');

        printStandardDocument({
          title: 'سجل الكشوفات الهندسية والمهام الميدانية الشامل',
          subtitle: `تاريخ التقرير: ${new Date().toLocaleDateString('ar-JO')} - إجمالي الكشوفات: ${this.tasks.length}`,
          summaryHtml: `
            <table style="width:100%; border-collapse:collapse; font-size:0.85rem; margin-top:14px;">
              <thead>
                <tr style="background:#1e3a8a; color:#fff;">
                  <th style="padding:8px; border:1px solid #1e3a8a; width:40px;">#</th>
                  <th style="padding:8px; border:1px solid #1e3a8a; width:90px;">رقم المهمة</th>
                  <th style="padding:8px; border:1px solid #1e3a8a;">عنوان المهمة والكشف</th>
                  <th style="padding:8px; border:1px solid #1e3a8a;">الاستدعاء / المواطن</th>
                  <th style="padding:8px; border:1px solid #1e3a8a;">المهندس المكلف</th>
                  <th style="padding:8px; border:1px solid #1e3a8a; width:70px;">الأولوية</th>
                  <th style="padding:8px; border:1px solid #1e3a8a; width:80px;">الحالة</th>
                  <th style="padding:8px; border:1px solid #1e3a8a; width:85px;">الاستحقاق</th>
                </tr>
              </thead>
              <tbody>
                ${rowsHtml || '<tr><td colspan="8" style="text-align:center; padding:15px;">لا توجد سجلات</td></tr>'}
              </tbody>
            </table>
          `,
          signatures: true
        });
      } else {
        window.print();
      }
    }

    showToast(msg) {
      if (typeof window.showToast === 'function') {
        window.showToast(msg);
      } else {
        alert(msg);
      }
    }
  }

  // Global Singleton Instance & Initialization
  window.unifiedMyWorkManager = new UnifiedMyWorkManager();

  window.loadMyWorkModule = function () {
    window.unifiedMyWorkManager.init('my-work-tab-container');
  };

  // Auto-init on DOMContentLoaded if active
  document.addEventListener('DOMContentLoaded', () => {
    const cont = document.getElementById('my-work-tab-container') || document.getElementById('page-my-work');
    if (cont && cont.style.display !== 'none') {
      window.unifiedMyWorkManager.init();
    }
  });

})();
