/**
 * scripts/test-phase10-rbac-matrix.js
 * 🔐 مصفوفة فحص الصلاحيات الإنتاجية الشاملة (Phase 10 RBAC Matrix Suite)
 * بلدية كفرنجة الجديدة - مديرية الأشغال والخدمات الهندسية
 */

const rbacManager = require('../middlewares/rbacManager');

async function runPhase10RbacMatrixTestSuite() {
  console.log('═══════════════════════════════════════════════════════════════════════════════');
  console.log('🔐 بدء فحص مصفوفة الصلاحيات والأدوار الإنتاجية (Phase 10 RBAC Matrix)');
  console.log('🏛️ بلدية كفرنجة الجديدة - مديرية الأشغال والخدمات الهندسية');
  console.log('═══════════════════════════════════════════════════════════════════════════════\n');

  let passed = 0;
  let failed = 0;

  function assert(condition, testName, details = '') {
    if (condition) {
      console.log(`  ✅ [PASS] ${testName} ${details ? '(' + details + ')' : ''}`);
      passed++;
    } else {
      console.error(`  ❌ [FAIL] ${testName} ${details ? '(' + details + ')' : ''}`);
      failed++;
    }
  }

  try {
    const roles = {
      admin: { id: 'U-001', role: 'admin', permissions: ['*'] },
      dept_head: { id: 'U-003', role: 'dept_head', permissions: ['PROJECTS.VIEW', 'PROJECTS.APPROVE', 'CLAIMS.APPROVE'] },
      engineer: { id: 'U-002', role: 'engineer', permissions: ['PROJECTS.VIEW', 'PROJECTS.CREATE', 'ROADS.VIEW'] },
      accountant: { id: 'U-005', role: 'accountant', permissions: ['CLAIMS.VIEW', 'CLAIMS.AUDIT'] },
      inspector: { id: 'U-004', role: 'inspector', permissions: ['ROADS.VIEW', 'ROADS.INSPECT'] }
    };

    // 1. Admin - Wildcard Access
    assert(rbacManager.hasPermission(roles.admin, 'ANY_CUSTOM_ACTION'), 'Admin has full universal wildcard access');

    // 2. Dept Head - Approvals
    assert(rbacManager.hasPermission(roles.dept_head, 'PROJECTS.APPROVE') === true, 'Dept Head authorized for project approvals');
    assert(rbacManager.hasPermission(roles.dept_head, 'SETTINGS.MANAGE') === false, 'Dept Head unauthorized for system configuration');

    // 3. Engineer - Creation vs Approval
    assert(rbacManager.hasPermission(roles.engineer, 'PROJECTS.CREATE') === true, 'Engineer authorized to create projects');
    assert(rbacManager.hasPermission(roles.engineer, 'CLAIMS.APPROVE') === false, 'Engineer unauthorized to approve claims');

    // 4. Accountant - Financial Audit
    assert(rbacManager.hasPermission(roles.accountant, 'CLAIMS.AUDIT') === true, 'Accountant authorized for claim audits');
    assert(rbacManager.hasPermission(roles.accountant, 'PROJECTS.DELETE') === false, 'Accountant unauthorized to delete projects');

    // 5. Inspector - Roads Only
    assert(rbacManager.hasPermission(roles.inspector, 'ROADS.INSPECT') === true, 'Inspector authorized for road inspections');
    assert(rbacManager.hasPermission(roles.inspector, 'CONTRACTS.CREATE') === false, 'Inspector unauthorized for contract generation');
  } catch (err) {
    assert(false, 'RBAC matrix failure', err.message);
  }

  console.log('\n═══════════════════════════════════════════════════════════════════════════════');
  console.log(`📊 النتيجة الإجمالية لمصفوفة الصلاحيات: ${passed} نجح | ${failed} فشل`);
  console.log('═══════════════════════════════════════════════════════════════════════════════\n');

  return { passed, failed };
}

if (require.main === module) {
  runPhase10RbacMatrixTestSuite().then(res => process.exit(res.failed > 0 ? 1 : 0));
}

module.exports = runPhase10RbacMatrixTestSuite;
